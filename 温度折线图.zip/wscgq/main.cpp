#include "mainwindow.h"
#include <QApplication>

bool HEX_ASCL = false;//true真 默认假

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
