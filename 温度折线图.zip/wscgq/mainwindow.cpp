#include "mainwindow.h"
#include "ui_mainwindow.h"

//定义一个串口指针
QSerialPort *COM = new QSerialPort();//QSerialPort（实例化对象）  *COM串口指针
    // = new QSerialPort()创建QSerialPort 对象

//创建实例化 对象   初始化   属性装填   功能函数

float y_value = 0;  // 用于存储接收到的数据的浮点值

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
      , ui(new Ui::MainWindow)
{


    ui->setupUi(this);

    chart_1=new QChart;
    line = new QLineSeries;
    axis_x =new QValueAxis;
    axis_y =new QValueAxis;
    timer = new QTimer;
    View_Init();
    timer->setInterval(1000);//1000ms

    connect(timer,SIGNAL(timeout()),this,SLOT(onTimeout()));
    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts())//在一开始就刷新
    //QSerialPortInfo获取串口信息    availablePorts 可用端口
    {
        //addItem添加项   info.portName()  info.portName串口信息的名字
        ui->comboBox_availablePorts_COM->addItem(info.portName());
    }
    //信号与槽的连接函数  connect（）==》COM,SIGNAL(readyRead())接收到数据 执行==》RX_FUN()
    //参数 1.发送信号对象  2.发送的信号  3.接收信号对象  4要执行的 槽(函数)
    connect(COM,SIGNAL(readyRead()),this,SLOT(RX_FUN()));
}

MainWindow::~MainWindow()
{
    delete ui;
}


//按键刷新按钮
//MainWindow在主窗口使用   加上MainWindow
void MainWindow::on_key_Refresh_COM_clicked()
{

    // 清空当前的串口列表   否则之前刷新出来的会一直保留
    ui->comboBox_availablePorts_COM->clear();
    //点击后串口展开页面刷新
    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts())
    //QSerialPortInfo获取串口信息    availablePorts 可用端口
    {
        //addItem添加项   info.portName()  info.portName串口信息的名字
        ui->comboBox_availablePorts_COM->addItem(info.portName());
    }

}
//按键打开串口按钮
void MainWindow::on_key_onoff_COM_clicked()
{

    QSerialPort::BaudRate baudRate;//声明波特率变量  枚举型
    QSerialPort::StopBits stopBits;//声明停止位
    QSerialPort::DataBits dataBits;//声明数据位
    QSerialPort::Parity   checkBits;//声明奇偶检验位

    //平时后三个不变 ，直接赋值，不提供选择
    stopBits = QSerialPort::OneStop; // 停止位 1位
    dataBits = QSerialPort::Data8;//数据位 8位
    checkBits = QSerialPort::NoParity;//奇偶检验位 无

    if(ui->comboBox_botelv->currentText() == "9600")//下拉框当前文字是什么
    {
        baudRate = QSerialPort::Baud9600;
    }
    else if(ui->comboBox_botelv->currentText() == "115200")//下拉框当前文字是什么
    {
        baudRate = QSerialPort::Baud115200;
    }
    //以上仅是将对应数据放到对应的变量上还未实现到串口上

    //以下是将数值放入串口属性进行初始化  COM在上面已将其定义为QSerialPort类型  *COM串口指针
    //获取串口名字 comboBox_availablePorts_COM (串口框)->currentText() 获取串口框的当前文字
    COM->setPortName(ui->comboBox_availablePorts_COM->currentText());//获取串口名字
    COM->setBaudRate(baudRate);//获取波特率
    COM->setStopBits(stopBits);//获取停止位
    COM->setDataBits(dataBits);//获取数据位
    COM->setParity(checkBits);//获取奇偶检验位
    //串口操作 打开/关闭
    //   key_onoff_COM
    if(ui->key_onoff_COM->text() == "打开串口")
    {
        if(COM->open(QIODevice::ReadWrite) == true)
        {   //如果串口打开成功
            //ReadWrite(该设备可以读写)==true(真)
            ui->key_onoff_COM->setText("关闭串口");//打开串口框变为关闭串口框
            //点击开灯 ，LDE变红    setStyle(设置)  setStyleSheet设置样式表
            ui->LED1->setStyleSheet("background-color:red");//LED变成红色
        }
        else //串口打开不成功
        {
            QMessageBox::critical(this,"错误提示",
                                  "打开串口失败！或其他错误。\r\n请选择正确串口或该串口北站用");
        }
    }
    else if(ui->key_onoff_COM->text() == "关闭串口")
    {
        COM->close();//真正关闭串口
        ui->key_onoff_COM->setText("打开串口");//按键文字变为打开串口  此处只是关闭窗口 没有真正关闭
            //点击开灯 ，LDE变红    setStyle(设置)  setStyleSheet设置样式表
        ui->LED1->setStyleSheet("background-color:green");//LED变成绿色
    }
}

//按键点击发送函数
void MainWindow::on_key_COM_Tx_clicked()
{
    if(HEX_ASCL == false )
    {
        //两种数据toLatin1（转为ASCLL编码）和toLocaL8bit
        COM->write(ui->textEdit->toPlainText().toLatin1());//串口写数据（ASCll）（发送数据(获取写入栏的数据（需要转换)）
    }


    if(HEX_ASCL == true )
    {
        //两种数据toLatin1（转为ASCLL编码）和toLocaL8bit
        QString hexString = ui->textEdit->toPlainText();
        // 移除字符串中的空格（如果用户输入了空格分隔的十六进制值）
        hexString = hexString.remove(QRegExp("[\\s\\t\\n\\r]"));
        // 将十六进制字符串转换为字节数组
        QByteArray data = QByteArray::fromHex(hexString.toLatin1());
        COM->write(data);
        qDebug()<<data;
    }
}

void MainWindow::on_key_COM_Clean_clicked()
{
    ui->textEdit->clear();//清除发送区
}

//串口接收 要定义一个数组存储数据 用字节数组
void MainWindow::RX_FUN()
{
    QByteArray  buf;//定义字节数据 缓冲区 0xffff
    buf = COM->readAll();//接收数据（读）存到缓冲区buf
    QString str;//定义一个字符变量

    if(!buf.isEmpty())//buf.isEmpty()--buf空 如果缓冲区buf不为空
    {
        if(HEX_ASCL == false )
        {
            ui->LED1->setStyleSheet("background-color:green");//LED变成绿
            str = tr(buf);//tr将 字节数组类型 转换为  字符类型
            bool ok;
            y_value = str.toFloat(&ok);  // 将字符串转换为浮点数
            ui->textBrowser->insertPlainText(str);//在接收框显示
            ui->textBrowser->moveCursor(QTextCursor::End);//光标移到最后一行
            ui->textBrowser->textCursor().insertBlock();  // 插入一个新块（换行）
            //      ui->textBrowser->textCursor().insertText("\n"); // 直接插入换行符
            QString  temp;//用来取前两位字符，进行判断
            QString  shuju;//用来取两字符后的数据
            int shuju_int; //用来存转换后的数据
            temp = str.left(3);//从一串字符串左到右取字符  (协商好)

            int y_value_int = static_cast<int>(y_value);  // 使用 static_cast
            y_value_int = (int)y_value;
            ui->lcd_wendu->display(y_value_int);

            if( temp == "wd:")
            {
                shuju =str.mid(1);//从某处取字符到最后一个 (协商好)
                shuju_int = shuju.toInt();//字符型转整型
                ui->lcd_wendu->display(shuju_int);
            }
            if( temp == "sd:")
            {
                shuju =str.mid(3);
                shuju_int = shuju.toInt();
                ui->lcd_shidu->display(shuju_int);
            }
        }
        else
        {
            ui->LED1->setStyleSheet("background-color:blue");//LED变成绿
            QString hexString = buf.toHex().toUpper();

            ui->textBrowser->insertPlainText(hexString);//在接收框显示
            ui->textBrowser->moveCursor(QTextCursor::End);//光标移到最后一行
            ui->textBrowser->textCursor().insertBlock();  // 插入一个新块（换行）
        }
    }

}

void MainWindow::on_qcjs_clicked()
{
    ui->textBrowser->clear();
}

void MainWindow::on_ASC_HEX_clicked() //HEX true //用来切换HEX和SCALL
{                                     //SCALL false
    if(ui->ASC_HEX->text() == "ASCll")
    {
        ui->ASC_HEX->setText("HEX");//按键文字变为打开串口  此处只是关闭窗口 没有真正关闭
        HEX_ASCL=true;//
    }
    else if(ui->ASC_HEX->text() == "HEX")
    {
        ui->ASC_HEX->setText("ASCll");//打开串口框变为关闭串口框
        HEX_ASCL=false;//
    }
    qDebug()<<HEX_ASCL;
}


void MainWindow::View_Init(){
    //第一步设置标题和坐标轴
    //设置标题
    chart_1=new QChart;
    chart_1->setTitle("y=sin(0.1x)");
    ui->graphicsView->setChart(chart_1);
    //设置x轴
    axis_x->setTickCount(11);  // 设置 11 个刻度（0, 1, 2, ..., 10）
    axis_x->setTickInterval(1);  // 设置刻度间隔为 1
    axis_x->setTitleText("值");
    axis_x->setRange(0,10);//设置值域
    chart_1->addAxis(axis_x,Qt::AlignBottom);//沿底边显示
    //设置y轴

    axis_y->setTitleText("值");
    axis_y->setTickCount(12);  // 设置 11 个刻度（0, 1, 2, ..., 10）
    axis_y->setTickInterval(1);  // 设置刻度间隔为 1
    axis_y->setRange(-1,11);//设置值域
    chart_1->addAxis(axis_y,Qt::AlignLeft);//沿底边显示

    //第二步增加数据

    //    line->setName("曲线y=sin(0.1x)");
    chart_1->addSeries(line);
    //    qreal y;
    //    for(int x=0;x<100;x++){
    //        y=qSin(0.1*x);
    //        line->append(x,y);
    //    }
    line->attachAxis(axis_x);//绑定x轴
    line->attachAxis(axis_y);//绑定y轴

    // 将系列关联到坐标轴
    line->attachAxis(axis_x); // 绑定x轴
    line->attachAxis(axis_y); // 绑定y轴

    // 添加超出x轴初始值域的数据点
    //    line->append(130, 1.5);
    //    line->append(150, 0.5);

    //    // 动态调整x轴值域以包含新数据点
    //    axis_x->setRange(0, 150);

}
void MainWindow::onTimeout(){
    //用户操作函数
    static int cout = 0;
    if(cout>10){
        line->remove(0); // 移除最早的数据点
        chart_1->axisX()->setMin(cout-10);//10注意修改
        chart_1->axisX()->setMax(cout);
    }
    // line->append(QPoint(cout,rand()%10));//rand() 是 C++ 标准库中的随机数生成函数
    line->append(QPoint(cout,y_value));
    cout++;



}

void MainWindow::on_pushButton_clicked(bool checked)
{
    if(checked){
        timer->start();
        ui->pushButton->setText("结束");

    }else{
        timer->stop();
        ui->pushButton->setText("开始");

    }
}
