#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QValueAxis>
#include <QLineSeries>  //它通常与 QChart、QValueAxis 等类一起使用，用于创建和显示图表。
#include <QPointF>
#include <QTimer>  // 包含QTimer类的头文件，用于定时器功能
#include "string.h"
#include <QMainWindow>  // 包含QMainWindow类的头文件
#include <qserialportinfo.h>  // 包含QSerialPortInfo类的头文件，用于获取串口信息
#include <QSerialPortInfo>  // 同上
#include <QtSerialPort>  // 包含Qt串口通信相关的头文件
#include <QMessageBox>  // 包含QMessageBox类的头文件，用于弹出消息框

#include <QtCharts/QtCharts>  // 包含Qt图表库的头文件

#include <QtCharts/QChartView>  // 包含QChartView类的头文件，用于显示图表
#include <QtCharts/QAbstractAxis>  // 包含QAbstractAxis类的头文件，用于图表的坐标轴
#include <QtCharts/QchartView>


extern bool HEX_ASCL;  //HEX_ASC 用来判断
QT_BEGIN_NAMESPACE

namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    //私有的 槽函数
private slots:

    void on_key_Refresh_COM_clicked();//按键刷新按钮
    void on_key_onoff_COM_clicked();//按键打开串口按钮
    void on_key_COM_Tx_clicked();
    void on_key_COM_Clean_clicked();
    void RX_FUN();
    void on_qcjs_clicked();
    void on_ASC_HEX_clicked();
    //自定义槽函数
    void View_Init();
    void onTimeout();

    void on_pushButton_clicked(bool checked);

private:
    Ui::MainWindow *ui;
    QLineSeries *line  ;
    QChart *chart_1     = new QChart;  // 创建一个QChart对象，用于图表显示
    QLineSeries *View   = new QLineSeries;  // 创建一个QLineSeries对象，用于绘制曲线
    QValueAxis *axis_x ;  // 创建一个QValueAxis对象，用于X轴
    QValueAxis *axis_y  = new QValueAxis;  // 创建一个QValueAxis对象，用于Y轴
    QTimer *timer = new QTimer;//添加一个计时器
};
#endif // MAINWINDOW_H
