/********************************************************************************
** Form generated from reading UI file 'dianhua.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIANHUA_H
#define UI_DIANHUA_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dianhua
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGridLayout *gridLayout;
    QLabel *lb_cnt;
    QCheckBox *checkBox;
    QPushButton *btn_click;
    QPushButton *btn_search;
    QPushButton *btn_updata;
    QLineEdit *le_search;
    QPushButton *btn_clear;
    QPushButton *pushButton_5;
    QPushButton *btn_add;
    QPushButton *btn_shuxin;
    QTableWidget *tableWidget;
    QWidget *page_2;
    QWidget *widget;
    QGridLayout *gridLayout_4;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QWidget *widget_3;
    QGridLayout *gridLayout_2;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *lb_user;
    QPushButton *but_exit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *dianhua)
    {
        if (dianhua->objectName().isEmpty())
            dianhua->setObjectName(QString::fromUtf8("dianhua"));
        dianhua->resize(979, 509);
        dianhua->setMinimumSize(QSize(800, 480));
        dianhua->setMaximumSize(QSize(16777215, 16777215));
        dianhua->setSizeIncrement(QSize(0, 0));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/RC.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        dianhua->setWindowIcon(icon);
        dianhua->setStyleSheet(QString::fromUtf8("background-color: rgb(117, 120, 173);"));
        centralwidget = new QWidget(dianhua);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setToolTipDuration(-1);
        stackedWidget->setStyleSheet(QString::fromUtf8(""));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        gridLayout = new QGridLayout(page);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lb_cnt = new QLabel(page);
        lb_cnt->setObjectName(QString::fromUtf8("lb_cnt"));

        gridLayout->addWidget(lb_cnt, 3, 3, 1, 1);

        checkBox = new QCheckBox(page);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 0, 0, 1, 1);

        btn_click = new QPushButton(page);
        btn_click->setObjectName(QString::fromUtf8("btn_click"));
        btn_click->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_click, 0, 5, 1, 1);

        btn_search = new QPushButton(page);
        btn_search->setObjectName(QString::fromUtf8("btn_search"));
        btn_search->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_search, 0, 8, 1, 1);

        btn_updata = new QPushButton(page);
        btn_updata->setObjectName(QString::fromUtf8("btn_updata"));
        btn_updata->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_updata, 0, 4, 1, 1);

        le_search = new QLineEdit(page);
        le_search->setObjectName(QString::fromUtf8("le_search"));
        le_search->setMaximumSize(QSize(600, 300));
        le_search->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        gridLayout->addWidget(le_search, 0, 6, 1, 1);

        btn_clear = new QPushButton(page);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));

        gridLayout->addWidget(btn_clear, 3, 1, 1, 1);

        pushButton_5 = new QPushButton(page);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        gridLayout->addWidget(pushButton_5, 3, 0, 1, 1);

        btn_add = new QPushButton(page);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));
        btn_add->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_add, 0, 3, 1, 1);

        btn_shuxin = new QPushButton(page);
        btn_shuxin->setObjectName(QString::fromUtf8("btn_shuxin"));

        gridLayout->addWidget(btn_shuxin, 3, 2, 1, 1);

        tableWidget = new QTableWidget(page);
        if (tableWidget->rowCount() < 1)
            tableWidget->setRowCount(1);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setStyleSheet(QString::fromUtf8("background-color: #75afaf;\n"
""));
        tableWidget->horizontalHeader()->setStretchLastSection(true);
        tableWidget->verticalHeader()->setVisible(false);

        gridLayout->addWidget(tableWidget, 2, 0, 1, 12);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        stackedWidget->addWidget(page_2);

        gridLayout_3->addWidget(stackedWidget, 1, 0, 1, 1);

        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(500, 60));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(209, 255, 149);"));
        gridLayout_4 = new QGridLayout(widget);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 0, 0, 1, 1);

        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMargin(-2);

        gridLayout_4->addWidget(label, 0, 1, 1, 1);

        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMinimumSize(QSize(360, 50));
        gridLayout_2 = new QGridLayout(widget_3);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(70, 60));
        label_3->setStyleSheet(QString::fromUtf8("border-image: url(:/long.jpg);"));

        gridLayout_2->addWidget(label_3, 0, 0, 1, 1);

        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 60));
        label_2->setStyleSheet(QString::fromUtf8(""));

        gridLayout_2->addWidget(label_2, 0, 1, 1, 1);

        lb_user = new QLabel(widget_3);
        lb_user->setObjectName(QString::fromUtf8("lb_user"));
        lb_user->setMinimumSize(QSize(0, 30));
        lb_user->setMaximumSize(QSize(16777215, 40));
        lb_user->setStyleSheet(QString::fromUtf8(""));

        gridLayout_2->addWidget(lb_user, 0, 2, 1, 1);

        but_exit = new QPushButton(widget_3);
        but_exit->setObjectName(QString::fromUtf8("but_exit"));
        but_exit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 199, 255);"));

        gridLayout_2->addWidget(but_exit, 0, 3, 1, 1);


        gridLayout_4->addWidget(widget_3, 0, 2, 1, 1);

        gridLayout_4->setColumnStretch(0, 1);
        gridLayout_4->setColumnStretch(1, 1);
        gridLayout_4->setColumnStretch(2, 1);

        gridLayout_3->addWidget(widget, 0, 0, 1, 1);

        dianhua->setCentralWidget(centralwidget);
        menubar = new QMenuBar(dianhua);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 979, 25));
        dianhua->setMenuBar(menubar);
        statusbar = new QStatusBar(dianhua);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        dianhua->setStatusBar(statusbar);

        retranslateUi(dianhua);

        QMetaObject::connectSlotsByName(dianhua);
    } // setupUi

    void retranslateUi(QMainWindow *dianhua)
    {
        dianhua->setWindowTitle(QApplication::translate("dianhua", "\346\225\260\346\215\256\347\225\214\351\235\242", nullptr));
#ifndef QT_NO_TOOLTIP
        dianhua->setToolTip(QApplication::translate("dianhua", "\346\225\260\346\215\256\347\225\214\351\235\242", nullptr));
#endif // QT_NO_TOOLTIP
        lb_cnt->setText(QString());
        checkBox->setText(QApplication::translate("dianhua", "\345\205\250\351\200\211", nullptr));
        btn_click->setText(QApplication::translate("dianhua", "\345\210\240\351\231\244", nullptr));
        btn_click->setProperty("btn", QVariant(QApplication::translate("dianhua", "main", nullptr)));
        btn_search->setText(QApplication::translate("dianhua", "\346\220\234\347\264\242", nullptr));
        btn_search->setProperty("btn", QVariant(QApplication::translate("dianhua", "main", nullptr)));
        btn_updata->setText(QApplication::translate("dianhua", "\344\277\256\346\224\271", nullptr));
        btn_updata->setProperty("btn", QVariant(QApplication::translate("dianhua", "main", nullptr)));
        le_search->setText(QString());
        btn_clear->setText(QApplication::translate("dianhua", "\346\270\205\347\251\272\345\255\246\347\224\237\350\241\250", nullptr));
        pushButton_5->setText(QApplication::translate("dianhua", "\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
        btn_add->setText(QApplication::translate("dianhua", "\345\242\236\345\212\240", nullptr));
        btn_add->setProperty("btn", QVariant(QApplication::translate("dianhua", "main", nullptr)));
        btn_shuxin->setText(QApplication::translate("dianhua", "\345\210\267\346\226\260", nullptr));
        tableWidget->setProperty("btn", QVariant(QApplication::translate("dianhua", "main", nullptr)));
        label->setText(QApplication::translate("dianhua", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt;\">\345\255\246\347\224\237\344\277\241\346\201\257\347\260\277</span></p></body></html>", nullptr));
        label_3->setText(QString());
        label_2->setText(QApplication::translate("dianhua", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        lb_user->setText(QApplication::translate("dianhua", "admin", nullptr));
        but_exit->setText(QApplication::translate("dianhua", "\351\200\200\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class dianhua: public Ui_dianhua {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIANHUA_H
