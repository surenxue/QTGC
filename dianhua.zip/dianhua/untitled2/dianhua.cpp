#include "dianhua.h"
#include "ui_dianhua.h"


#include <QKeyEvent>
#include <QFile>
#include <QCoreApplication>
#include <QRandomGenerator>
#include <QtSql>
#include <QMessageBox>
dianhua::dianhua(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::dianhua)
{
    ui->setupUi(this);

    m_dlgLogin.show();//执行m_dlgLogin队列  形成一个模块对话框 调用界面  打开登录界面

    //收到发送成功就自动引用
    auto f=[&](){
        this->show();
    };
    //当 sendLoginSuccess(在登录按钮槽函数用enit激发) 信号被触发时，Lambda 函数 f 会被调用，从而执行 this->show()。
    //获取来自 m_dlgLogin 界面下的 登录按钮 触发信号   Lambda 函数 f 会被调用，从而执行 this->show()。
    connect(&m_dlgLogin,&Paeg_long::sendLoginSuccess,this,f);//用于连接信号和槽的语法


    m_ptrStuSql = stuSql::getinstance();
    m_ptrStuSql->init();//默认不打开数据库，需要初始化打开

    m_lName<<"终嘉音";
    m_lName<<"礼洁玉";
    m_lName<<"诸沛凝";
    m_lName<<"曾锦曦";
    m_lName<<"毛梓欣";
    m_lName<<"崇欣";
    m_lName<<"司徒访";
    m_lName<<"军平绿";
    m_lName<<"颛孙语";
    m_lName<<"关丰茂";
    m_lName<<"景幻梅";
    m_lName<<"桥夏月";
    m_lName<<"后晴美";
    m_lName<<"硕尔柳";
    m_lName<<"冠漠";
    m_lName<<"书寄蓉";
    m_lName<<"薛春绿";
    m_lName<<"箕温纶";
    m_lName<<"敏元菱";
    m_lName<<"宜雪枫";
    m_lName<<"贵同甫";
    m_lName<<"牢惜雪";
    m_lName<<"己雪帆";
    m_lName<<"达樱花";
    m_lName<<"祁新觉";
    m_lName<<"玉莹华";
    m_lName<<"念梦凡";
    m_lName<<"聂家美";
    m_lName<<"向精 " ;
    m_lName<<"五曼岚";
    m_lName<<"师天空";
    m_lName<<"戢芮雅";
    m_lName<<"柔才捷";
    m_lName<<"子车宏";
    m_lName<<"风彩萱";
    m_lName<<"锁和平";
    m_lName<<"丑向松";
    m_lName<<"汉骏祥";
    m_lName<<"简博简";
    m_lName<<"臧云韶";
    m_lName<<"泷凡白";
    m_lName<<"竹易巧";
    m_lName<<"罕寄蓝";
    m_lName<<"钦运华";
    m_lName<<"令琴音";
    m_lName<<"拱恨风";
    m_lName<<"字怀柔";
    m_lName<<"系慕蕊";
    m_lName<<"窦半兰";
    m_lName<<"廉访儿";
    m_lName<<"岑梦月";
    m_lName<<"烟平卉";
    m_lName<<"帖恬默";
    m_lName<<"夷兴思";
    m_lName<<"闾丘萝";
    m_lName<<"褚迎夏";
    m_lName<<"邸丽珠";
    m_lName<<"象郁 " ;
    m_lName<<"端木雪";
    m_lName<<"夏高畅";
    m_lName<<"卓芳 " ;
    m_lName<<"隆亦梅";
    m_lName<<"明忆南";
    m_lName<<"涂代灵";
    m_lName<<"谌芳泽";
    m_lName<<"帅玮艺";
    m_lName<<"沙含蕊";
    m_lName<<"段添 ";
    m_lName<<"旗冷雪";
    m_lName<<"尉凯凯";
    m_lName<<"续痴瑶";
    m_lName<<"康景行";
    m_lName<<"门冰双";
    m_lName<<"红诗柳";
    m_lName<<"无春燕";
    m_lName<<"杨怀莲";
    m_lName<<"司马怀";
    m_lName<<"悉斯";
    m_lName<<"丹采萱";
    m_lName<<"长孙英";
    m_lName<<"以荌荌";
    m_lName<<"保涵蓄";
    m_lName<<"謇语柳";
    m_lName<<"蓟慧";
    m_lName<<"鲜哲";
    m_lName<<"摩醉巧";
    m_lName<<"费莫英";
    m_lName<<"愈荡" ;
    m_lName<<"劳方方";
    m_lName<<"须浦泽";
    m_lName<<"亥千亦";
    m_lName<<"成采柳";
    m_lName<<"陈然" ;
    m_lName<<"车晓筠";
    m_lName<<"昔晓燕";
    m_lName<<"童智晖";
    m_lName<<"徭书竹";
    m_lName<<"粟韵宁";
    m_lName<<"滑浩涆";
    m_lName<<"黎元容";
    m_lName<<"壬经纬";
    m_lName<<"晋盼晴";
    m_lName<<"巩冬梅";
    m_lName<<"士旋" ;
    m_lName<<"杞俊良";
    m_lName<<"佟雅柔";
    m_lName<<"真睿姿";
    m_lName<<"孟悦乐";
    m_lName<<"弓学林";
    m_lName<<"冷英卓";
    m_lName<<"辛白夏";
    m_lName<<"首以彤";
    m_lName<<"飞香桃";
    m_lName<<"俎丹红";
    m_lName<<"毋巧兰";
    m_lName<<"荆傲霜";
    m_lName<<"杜振荣";
    m_lName<<"郜望慕";
    m_lName<<"哀昆锐";
    m_lName<<"说良" ;
    m_lName<<"齐玄雅";
    m_lName<<"旅蕴秀";
    m_lName<<"偶空" ;
    m_lName<<"归尔晴";
    m_lName<<"厍嘉悦";
    m_lName<<"覃问筠";
    m_lName<<"柏凌兰";
    m_lName<<"乌曼丽";
    m_lName<<"束青枫";
    m_lName<<"葛远" ;
    m_lName<<"海红螺";
    m_lName<<"端嘉赐";
    m_lName<<"修乐悦";
    m_lName<<"登蓓" ;
    m_lName<<"印白卉";
    m_lName<<"笪情文";
    m_lName<<"上官妙";
    m_lName<<"邶抒" ;
    m_lName<<"示子辰";
    m_lName<<"隗娜兰";
    m_lName<<"迟灵" ;
    m_lName<<"瞿悦来";
    m_lName<<"巢雅致";
    m_lName<<"建从筠";
    m_lName<<"谯澜" ;
    m_lName<<"那拉蓓";
    m_lName<<"庆沛春";
    m_lName<<"浑紫雪";
    m_lName<<"翁山梅";
    m_lName<<"集佩珍";
    m_lName<<"甫小雨";
    m_lName<<"文诗蕾";
    m_lName<<"巧白易";
    m_lName<<"邗欣美";
    m_lName<<"商玉韵";
    m_lName<<"咎语彤";
    m_lName<<"仍德华";
    m_lName<<"淡雁芙";
    m_lName<<"所偲偲";
    m_lName<<"吉泽 " ;
    m_lName<<"张简云";
    m_lName<<"贡思云";
    m_lName<<"山爰美";
    m_lName<<"公良力";
    m_lName<<"出语丝";
    m_lName<<"袁丝娜";
    m_lName<<"化高澹";
    m_lName<<"梅淼淼";
    m_lName<<"蒋凯" ;
    m_lName<<"巴向山";
    m_lName<<"牵雪峰";
    m_lName<<"始元蝶";
    m_lName<<"益曼冬";
    m_lName<<"台高寒";
    m_lName<<"苌曼文";
    m_lName<<"其悠婉";
    m_lName<<"宓秋白";
    m_lName<<"皇玉宸";
    m_lName<<"朴红豆";
    m_lName<<"百里秋";
    m_lName<<"危乐荷";
    m_lName<<"聊元武";
    m_lName<<"谷长" ;
    m_lName<<"仙忆曼";
    m_lName<<"漫书易";
    m_lName<<"桑英秀";
    m_lName<<"苍智敏";
    m_lName<<"宣景辉";
    m_lName<<"市晴霞";
    m_lName<<"沈语海";
    m_lName<<"定和昶";
    m_lName<<"纵怜容";
    m_lName<<"鄞代柔";
    m_lName<<"宋瑶岑";
    m_lName<<"天迎波";
    m_lName<<"强夏" ;
    m_lName<<"伏涵衍";
    m_lName<<"麴琼英";
    m_lName<<"谭骏年";
    m_lName<<"伟恩霈";
    m_lName<<"国献仪";
    m_lName<<"綦炳" ;
    m_lName<<"慕雁菱";
    m_lName<<"兆鸿博";
    m_lName<<"树淼" ;
    m_lName<<"载稷骞";
    m_lName<<"悟慧英";
    m_lName<<"扬洛" ;
    m_lName<<"游雨文";
    m_lName<<"洛凌翠";
    m_lName<<"夙寄波";
    m_lName<<"邴辰龙";
    m_lName<<"德忆秋";
    m_lName<<"抄杉" ;
    m_lName<<"析雪晴";
    m_lName<<"裘逸" ;
    m_lName<<"御寒天";
    m_lName<<"应盼" ;
    m_lName<<"祢雅丹";
    m_lName<<"铁初蝶";
    m_lName<<"东门丁";
    m_lName<<"京嘉瑞";
    m_lName<<"楚惠君";
    m_lName<<"辉涵桃";
    m_lName<<"路清昶";
    m_lName<<"温天韵";
    m_lName<<"凤平" ;
    m_lName<<"裴孤阳";
    m_lName<<"委新颖";
    m_lName<<"有国" ;
    m_lName<<"闳明洁";
    m_lName<<"籍流逸";
    m_lName<<"朋晟睿";
    m_lName<<"冼翰" ;
    m_lName<<"廖贞婉";
    m_lName<<"宾永宁";
    m_lName<<"督夏柳";
    m_lName<<"扈学真";
    m_lName<<"糜嘉誉";
    m_lName<<"亓翠丝";
    m_lName<<"张代珊";
    m_lName<<"申雯丽";
    m_lName<<"封若枫";
    m_lName<<"由思云";
    m_lName<<"从哲瀚";
    m_lName<<"候婉静";
    m_lName<<"张廖吉";
    m_lName<<"利文" ;
    m_lName<<"公叔蓝";
    m_lName<<"普芳润";
    m_lName<<"堂锐利";
    m_lName<<"鲜于令";
    m_lName<<"班盼香";
    m_lName<<"信凝心";
    m_lName<<"闫采春";
    m_lName<<"鲁飞兰";
    m_lName<<"速灵秀";
    m_lName<<"检丹雪";
    m_lName<<"穰芮美";
    m_lName<<"席彤霞";
    m_lName<<"闾恨荷";
    m_lName<<"局琲瓃";
    m_lName<<"琦魁" ;
    m_lName<<"之尔槐";
    m_lName<<"戚痴灵";
    m_lName<<"伍子轩";
    m_lName<<"犁俊风";
    m_lName<<"汤琅" ;
    m_lName<<"苏秋莲";
    m_lName<<"古英睿";
    m_lName<<"牟瑾 " ;
    m_lName<<"理冰菱";
    m_lName<<"函向 " ;
    m_lName<<"欧阳俊";
    m_lName<<"萨白萱";
    m_lName<<"轩辕津";
    m_lName<<"么衣" ;
    m_lName<<"称静姝";
    m_lName<<"帛思萱";
    m_lName<<"徐靖柏";
    m_lName<<"皋阳舒";
    m_lName<<"祈蝶" ;
    m_lName<<"校光亮";
    m_lName<<"泥暄和";
    m_lName<<"戴逸云";
    m_lName<<"刚清莹";
    m_lName<<"虎傲之";
    m_lName<<"似乐康";
    m_lName<<"星珺琦";
    m_lName<<"鞠冷" ;
    m_lName<<"赧雪绿";
    m_lName<<"脱剑" ;
    m_lName<<"扶凝梦";
    m_lName<<"宿恨蝶";
    m_lName<<"绳玉轩";
    m_lName<<"高寄文";
    m_lName<<"庞夜绿";
    m_lName<<"貊艳娇";
    m_lName<<"尧小楠";
    m_lName<<"鹿妙晴";
    m_lName<<"柯俊誉";
    m_lName<<"睦范" ;
    m_lName<<"召曼青";
    m_lName<<"栗建义";
    m_lName<<"侯悦和";
    m_lName<<"微生清";
    m_lName<<"荀钊" ;
    m_lName<<"傅雅静";
    m_lName<<"户秀丽";
    m_lName<<"狄初夏";
    m_lName<<"常濮存";
    m_lName<<"刁凝丝";
    m_lName<<"锐景铄";
    m_lName<<"蔺寄柔";
    m_lName<<"能蕴涵";
    m_lName<<"仝含之";
    m_lName<<"叔琳溪";
    m_lName<<"顿玉珂";
    m_lName<<"柴晨朗";
    m_lName<<"梁诗蕾";
    m_lName<<"库白凡";
    m_lName<<"闻琬凝";
    m_lName<<"阙静婉";
    m_lName<<"魏骞魁";
    m_lName<<"俟凝海";
    m_lName<<"姚奕奕";
    m_lName<<"告听枫";
    m_lName<<"戎天亦";
    m_lName<<"勇叡" ;
    m_lName<<"怀颐" ;
    m_lName<<"程醉卉";
    m_lName<<"夏侯醉";
    m_lName<<"龚尔真";
    m_lName<<"留斯伯";
    m_lName<<"骆婉丽";
    m_lName<<"酆绿夏";
    m_lName<<"但优瑗";
    m_lName<<"田北辰";
    m_lName<<"索春雪";
    m_lName<<"用从阳";
    m_lName<<"羊沛蓝";
    m_lName<<"任秋白";
    m_lName<<"哈芬菲";
    m_lName<<"区安莲";
    m_lName<<"谢震轩";
    m_lName<<"赖庸" ;
    m_lName<<"梁丘乐";
    m_lName<<"双潍" ;
    m_lName<<"逢华彩";
    m_lName<<"纳喇安";
    m_lName<<"昂小蕊";
    m_lName<<"彭仙仪";
    m_lName<<"兰郎" ;
    m_lName<<"枚冷荷";
    m_lName<<"吴水蓉";
    m_lName<<"塞勇" ;
    m_lName<<"白绮晴";
    m_lName<<"段干芳";
    m_lName<<"镜淡 " ;
    m_lName<<"邬云亭";
    m_lName<<"清隽 " ;
    m_lName<<"李斌斌";
    m_lName<<"犹彭" ;
    m_lName<<"甲谷翠";
    m_lName<<"孙博文";
    m_lName<<"邝晴虹";
    m_lName<<"晏清婉";
    m_lName<<"余知慧";
    m_lName<<"酒乐意";
    m_lName<<"第泰清";
    updateTable();//刷新
}

dianhua::~dianhua()
{
    delete ui;
}

void dianhua::on_pushButton_5_clicked() //制作1000条学生数据
{
    // QRandomGenerator c;
    //c.seed(0);
    QList<StuInfo> l;//优化1
    for(int i=0;i<m_lName.size();i++){
        //auto  uiclass = c.bounded(0,10);//1~3随机 左包括右不包括 班级
        StuInfo info;

        info.xuhao = i+1;  //序号
        info.name=m_lName[i];
        info.phone = QString::number(20000 + i);
        info.password = QString::number(10000 + i);
        l.append(info);//info放在这个容器（数组）中  //优化2
         m_ptrStuSql->addStu(info);//原始
    }
    //m_ptrStuSql->addStu(l);//优化3

    updateTable();//刷新
}


void dianhua::updateTable()//刷新 下拉栏
{


    ui->tableWidget->clear();//会删除表头
    ui->tableWidget->setColumnCount(5);//设为8列
    QStringList l;//表头
    l<<"序号"<<"id"<<"姓名"<<"密码"<<"电话";//qDebug() << l[1]; // 输出：姓名
    ui->tableWidget->setHorizontalHeaderLabels(l);//设置水平

    //一行任意位置选中行  行为
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    //每个选项不可编辑
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    auto cnt = m_ptrStuSql->getStuCnt();//把所有数据拿出  // 根据函数返回值推断类型 自适应类型（自动变化）

    ui->lb_cnt->setText(QString("学生总数:%1").arg(cnt));
    QList<StuInfo> lStudents = m_ptrStuSql->getPageStu(0,cnt);//0页，cnt个
    //ui->tableWidget->clear();
    ui->tableWidget->setRowCount(cnt);//一共cnt个
    for(int i=0;i<lStudents.size();i++){
        //ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(i+1)));//主动的，不是读出的
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(lStudents[i].xuhao))); // 序号
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::number(lStudents[i].id)));     // id
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(lStudents[i].name));                   // 姓名
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(lStudents[i].password));              // 密码
        ui->tableWidget->setItem(i,4,new QTableWidgetItem(lStudents[i].phone));                 // 电话
          }

}


void dianhua::on_but_exit_clicked()//返回登录界面
{

    this->hide();  // 隐藏当前窗口
    m_dlgLogin.show();  // 显示登录窗口

}

void dianhua::on_btn_clear_clicked()//清除数据
{
    m_ptrStuSql->cleaStuTable(); //m_ptrStuSql调用成员函数 清除学生列表
    updateTable();//刷新
}


void dianhua::on_btn_click_clicked()//删除选中列
{
    int i = ui->tableWidget->currentRow();//获取当前是第几行
    if(i>=0){
        int id = ui->tableWidget->item(i,1)->text().toUInt();
        m_ptrStuSql->delStu(id);
        updateTable();

        // 删除后重新排序序号并更新数据库
        for(int j = 0; j < ui->tableWidget->rowCount(); j++) {
            // 获取当前行的学生信息
            StuInfo info;
            info.id = ui->tableWidget->item(j,1)->text().toUInt();
            info.xuhao = j + 1; // 新序号
            info.name = ui->tableWidget->item(j,2)->text();
            info.password = ui->tableWidget->item(j,3)->text();
            info.phone = ui->tableWidget->item(j,4)->text();

            // 更新表格显示
            ui->tableWidget->item(j,0)->setText(QString::number(j+1));
            // 更新数据库
            m_ptrStuSql->UpdataStuInfo(info);
        }
        QMessageBox::information(nullptr,"信息","删除成功");
    }
}


void dianhua::on_btn_shuxin_clicked()//刷新
{
    updateTable();//刷新
}


void dianhua::on_btn_search_clicked()//刷新
{
    QString strFile = ui->le_search->text();
    if(strFile.isEmpty()){
        QMessageBox::information(nullptr,"警告","名字筛选为空");
        updateTable();
        return;
    }

    ui->tableWidget->clear();//会删除表头
    ui->tableWidget->setColumnCount(5);//设为5列
    QStringList l;//表头
    l<<"序号"<<"id"<<"姓名"<<"密码"<<"电话";
    ui->tableWidget->setHorizontalHeaderLabels(l);//设置水平表头

    //一行任意位置选中行  行为
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    //每个选项不可编辑
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    //获取所有学生数据
    QList<StuInfo> lStudents = m_ptrStuSql->getPageStu(0, m_ptrStuSql->getStuCnt());
    int index = 0;

    //清空表格并动态添加匹配的行
    ui->tableWidget->setRowCount(0);
    
    for(int i=0;i<lStudents.size();i++){
        QString studentIdStr = QString::number(lStudents[i].xuhao);
        //按姓名或序号搜索
        if(lStudents[i].name.contains(strFile) || studentIdStr.contains(strFile)){
            StuInfo updatedInfo = lStudents[i];
            int newXuhao = index + 1; // 重新排序序号从1开始


            ui->tableWidget->insertRow(index);
            ui->tableWidget->setItem(index,0,new QTableWidgetItem(QString::number(newXuhao)));
            ui->tableWidget->setItem(index,1,new QTableWidgetItem(QString::number(updatedInfo.id)));
            ui->tableWidget->setItem(index,2,new QTableWidgetItem(updatedInfo.name));
            ui->tableWidget->setItem(index,3,new QTableWidgetItem(updatedInfo.password));
            ui->tableWidget->setItem(index,4,new QTableWidgetItem(updatedInfo.phone));


            index++;
        }
    }


    
    ui->lb_cnt->setText(QString("匹配数量:%1").arg(index));
}


void dianhua::on_btn_updata_clicked()//点击添加后弹出窗口的属性
{
    StuInfo info;
    int i = ui->tableWidget->currentRow();//获取当前是第几行
    if(i>=0){
        //拿出主界面选中信息
        info.xuhao  = ui->tableWidget->item(i,0)->text().toUInt();  // 序号列索引改为0
        info.id = ui->tableWidget->item(i,1)->text().toUInt();      // id列索引改为1
        info.name   = ui->tableWidget->item(i,2)->text();           // 姓名列索引改为2
        info.password  = ui->tableWidget->item(i,3)->text();        // 密码列索引改为3
        info.phone  = ui->tableWidget->item(i,4)->text();           // 电话列索引改为4

        m_dlgAddStu.setType(false,info);//false表示修改模式
        m_dlgAddStu.exec();// 阻塞 强制完成当前窗口（必须有个返回）  模态对话框
    }
    updateTable();//刷新
}


void dianhua::on_btn_add_clicked()
{
    //m_dlgAddStu.show();//声明完后按钮启动新界面  显示屏幕

    //无需输入数据   就直接启动文件（窗口）
    m_dlgAddStu.setType(true);
    m_dlgAddStu.exec();// 阻塞 强制完成当前窗口（必须有个返回）  模态对话框    m_dlgAddStu 是  Dlg_AddStu 窗口下的一个对象    开启窗口
    //m_dlgAddStu.show();打开，与其他界面共存
    updateTable();//刷新
}

