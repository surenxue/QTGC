#include "paeg_long.h"
#include "ui_paeg_long.h"

Paeg_long::Paeg_long(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Paeg_long)
{
    ui->setupUi(this);



}
Paeg_long::~Paeg_long()
{
    delete ui;
}
void Paeg_long::on_but_exit_clicked()
{
    exit(0);//程序退出
}
void Paeg_long::on_but_login_clicked()
{

    /*
    QString username = ui->le_user->text();
    QString password = ui->le_password->text();

    // 先获取实例 //会触发单例对象的创建 触发构造函数  单例初始化时的副作用 (构造函数会被再次调用)
     stuSql* db = stuSql::getinstance();

    //用来实际查询用户
    //bool exists = db->isExit(username); //常实现为执行 SELECT COUNT(*) FROM table WHERE name = ? 查询

       StuInfo user = db->getUserInfoByName(username);
       if(!user.name.isEmpty()) {  // 检查从数据库获取的用户信息对象中的name字段是否为空 为空，表示没有查询到该用户名的记录
        if(user.password == password) {  // 验证密码
            emit sendLoginSuccess();
            this->hide();
            ui->le_user->clear();
            ui->le_password->clear();
        } else {
            QMessageBox::warning(this, "登录失败", "密码错误！");
        }
    } else {
        QMessageBox::warning(this, "登录失败", "用户名不存在！");
    }
*/

     //点击即可登录
    emit sendLoginSuccess();//sendLoginSuccess() 是一个信号函数。 emit 关键字用于触发这个信号。
    this->hide();//隐藏当前界面，没有重置
    //在切换时清楚数据
    ui->le_user->clear();
    ui->le_password->clear();

}

