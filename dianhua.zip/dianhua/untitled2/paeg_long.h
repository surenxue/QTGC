#ifndef PAEG_LONG_H
#define PAEG_LONG_H

#include <QWidget>
#include "stusql.h"
#include <QMessageBox>
namespace Ui {
class Paeg_long;
}

class Paeg_long : public QWidget
{
    Q_OBJECT

public:
    explicit Paeg_long(QWidget *parent = nullptr);
    ~Paeg_long();

private slots:
    void on_but_exit_clicked();

    void on_but_login_clicked();

signals:
    void sendLoginSuccess();


private:
    Ui::Paeg_long *ui;
};

#endif // PAEG_LONG_H
