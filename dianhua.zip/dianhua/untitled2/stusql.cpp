#include "stusql.h"
#include <QMessageBox>
#include <QCoreApplication>
#include <QtSql>
#include <QtDebug>
stuSql *stuSql::ptrstuSql =nullptr;

//id（唯一值= 被设为唯一值的）
stuSql::stuSql(QObject *parent)
    : QObject{parent}
{
    init();

    // StuInfo s;
    // s.xuhao = 1;
    // s.name = " ";
    // s.phone = "12345678";
    // s.id = 10;
    // s.password = "11111";
    // updateStuByStudentId(s);
    //addStu(s);//添加用户  ok
    // auto l = getStuCnt();//查询所有用户        ok
    // qDebug()<<l;
    //getPageStu(0,2);//从第0页查，每页2个       ok
    // delStu(9);//输入id进行删除     ok
    //cleaStuTable();//清空数据     ok
    // UpdataStuInfo(s);//为现有对象添加id属性进行查找定位修改对象 id不可修改       ok
    //qDebug()<<isExit("adad"); //查询用户 完成
    //updateStuByStudentId(s);

}

void stuSql::init()//初始化
{

    // 1. 检查驱动可用性
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        QMessageBox::critical(nullptr, "错误", "SQLite驱动不可用");
        return;
    }

    // 2. 创建数据库连接
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    // 3. 设置数据库文件路径
    //1.自获取数据库地址
     auto str = QCoreApplication::applicationDirPath()+"\\dh.db";//程序发给别人需要装上一个数据库（获取应用程序当前Debug的路径）
     qDebug()<< str;

    //2.确定数据库地址
   // auto str = "C:\\Users\\Administrator\\Desktop\\QTgc\\dianhua\\untitled2\\dh.db";

    m_db.setDatabaseName(str);//设置数据库路径( str = 数据库路径)

    // 4. 打开数据库连接
    if (!m_db.open())//判断数据库是否打开 m_db.open() 会尝试打开数据库连接  判断同时打开数据库
    {
        QString errorMsg = QString("数据库打开失败:\n%1\n驱动错误:%2")
                               .arg(m_db.lastError().databaseText())
                               .arg(m_db.lastError().driverText());
        QMessageBox::critical(nullptr, "数据库错误", errorMsg);
        return;
    }
    QSqlQuery q("",m_db);

    //INSERT INTO dhb(自己的表名) values(null(设为主键的空),2,'afjdsd','31434');//（内部按表结构输入数据）
    //q.exec("INSERT INTO dhb values(null,2,'afjdsd','31434');");
}

quint32 stuSql::getStuCnt()//根据 id 唯一的查（设为主键的）数
{
    QSqlQuery sql(m_db);
    sql.exec("select count(id) from dhb;");//根据 id 唯一的查（设为主键的）数
    quint32 uiCnt=0;
    while(sql.next()){
        uiCnt =  sql.value(0).toUInt();
    }
    //qDebug()<<uiCnt;
    return uiCnt;
}

QList<StuInfo> stuSql::getPageStu(quint32 page, quint32 uiCint)//page-1页（0开始） uiCint（每页多少数据）
{
    /*   QList<StuInfo> l;
        - 准备了一个空的名片盒（QList）
        - 规定这个盒子里只能放用户名片（StuInfo）
        - 给这个盒子贴了个标签叫"l"
    */
    QList<StuInfo> l;

    QSqlQuery sql(m_db);
    //一页多少个 从哪开始
    QString  strsql = QString("select * from dhb order by id ASC limit %1 offset %2")
                         .arg(uiCint).arg(page*uiCint);
    sql.exec(strsql);//你要查多少个
    StuInfo info;
    while(sql.next()){
        info.id =  sql.value(0).toUInt();
        info.xuhao =  sql.value(1).toUInt();
        info.name = sql.value(2).toString();
        info.password= sql.value(3).toString();
        info.phone =  sql.value(4).toString();

        l.push_back(info);
    }

    return l;
}

bool stuSql::addStu(StuInfo info)//添加用户
{
    QSqlQuery sql(m_db);
    QString strSql = QString("INSERT INTO dhb values(null,%1,'%2','%3','%4');")
                    .arg(info.xuhao)
                    .arg(info.name)
                    .arg(info.password)
                    .arg(info.phone);
    // auto asd = sql.exec(strSql);
    // qDebug()<<asd;
    //return sql.exec(strSql);

    // 正确检查用户是否存在
    if(!isExit(info.name)) { // 直接检查用户名
        return sql.exec(strSql); // 用户不存在，执行插入
    } else {
        qDebug() << "用户已存在，不重复添加";
        return false; // 返回false表示未插入
    }
}

bool stuSql::delStu(int id)
{
    QSqlQuery sql(m_db);

    return sql.exec(QString("delete from dhb where id = %1;").arg(id));;
}

bool stuSql::cleaStuTable()
{
    QSqlQuery sql(m_db);
    //当删除在中间的id数据时,想要重置（只能重新创建一个新表将回数据传过去（将原本的ID重置），在拿回来）

    sql.exec("delete from dhb ");//清空数据库（保留自增ID计数）
    return sql.exec("delete from sqlite_sequence where name='dhb'");//重置自增ID计数器（必须配合上条语句使用）
}

bool stuSql::UpdataStuInfo(StuInfo info)
{
    QSqlQuery sql(m_db);
    // 使用预编译语句和参数绑定，避免 SQL 注入
    //采用数据库中的字段(注意空格)  不是自己的变量名
    //修改对应位置即可 （修改索引）
    QString strSql = QString("update dhb set xuhao=%1,name ='%2',phone='%3',password='%4'  where id=%5")
                         .arg(info.xuhao)
                         .arg(info.name)
                         .arg(info.phone)
                         .arg(info.password)
                         .arg(info.id);
    bool ret = sql.exec(strSql);
    QSqlError e = sql.lastError();
    if(e.isValid()){
        qDebug()<<e.text();
    }
    return ret;
}

bool stuSql::updateStuByStudentId(StuInfo info)//info 含有name 来进行索引
{
    QSqlQuery sql(m_db);
    //采用数据库中的字段(注意空格)  不是自己的变量名
    QString strSql = QString("update dhb set xuhao=%1,id=%2,phone='%3',password='%4'  where name='%5'")
                         .arg(info.xuhao)
                         .arg(info.id)
                         .arg(info.phone)
                         .arg(info.password)
                         .arg(info.name);
    bool ret = sql.exec(strSql);
    QSqlError e = sql.lastError();
    if(e.isValid()){
        qDebug()<<e.text();
    }
    return ret;
}

bool stuSql::isExit(QString info)
{
    QSqlQuery sql(m_db);

    //sql.exec(QString("select *from name where name='%1'").arg(info));
    //使用 SELECT 1 替代 SELECT * （只需知道是否存在记录，不需要返回全部字段  避免资源浪费 ：
    if(!sql.exec(QString("SELECT 1 FROM dhb WHERE name='%1'").arg(info))) {
        qDebug() << "查询失败:" << sql.lastError().text();
        return false;
    }
    return sql.next();
}

StuInfo stuSql::getUserInfoByName(const QString &username)
{
    StuInfo info;  // 创建空用户信息对象

    QSqlQuery sql(m_db);
    // 查询所有字段
    sql.prepare("SELECT * FROM dhb WHERE name = ?");
    sql.addBindValue(username);

    if(sql.exec() && sql.next()) {
        // 从查询结果填充用户信息对象
        info.id = sql.value("id").toInt();
        info.name = sql.value("name").toString();
        info.xuhao = sql.value("xuhao").toInt();
        info.phone = sql.value("phone").toString();
        info.password = sql.value("password").toString();
        // 如果有其他字段也可以继续添加...
    }
    else {
        qDebug() << "查询用户信息失败:" << sql.lastError().text();
    }
    return info;  // 返回用户信息对象
}
