/********************************************************************************
** Form generated from reading UI file 'paeg_long.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAEG_LONG_H
#define UI_PAEG_LONG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Paeg_long
{
public:
    QGridLayout *gridLayout_3;
    QLabel *label_3;
    QWidget *widget_4;
    QGridLayout *gridLayout_4;
    QSpacerItem *horizontalSpacer_2;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *lb1;
    QLineEdit *le_password;
    QLineEdit *le_user;
    QLabel *lb2;
    QSpacerItem *horizontalSpacer;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QPushButton *but_login;
    QPushButton *but_exit;

    void setupUi(QWidget *Paeg_long)
    {
        if (Paeg_long->objectName().isEmpty())
            Paeg_long->setObjectName(QString::fromUtf8("Paeg_long"));
        Paeg_long->resize(422, 264);
        Paeg_long->setMinimumSize(QSize(422, 264));
        Paeg_long->setMaximumSize(QSize(422, 264));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/long.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        Paeg_long->setWindowIcon(icon);
        gridLayout_3 = new QGridLayout(Paeg_long);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_3 = new QLabel(Paeg_long);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QFont font;
        font.setPointSize(20);
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("\n"
"border-image: url(:/\344\270\213\350\275\275.jpg);"));
        label_3->setAlignment(Qt::AlignmentFlag::AlignCenter);

        gridLayout_3->addWidget(label_3, 0, 0, 1, 1);

        widget_4 = new QWidget(Paeg_long);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        gridLayout_4 = new QGridLayout(widget_4);
        gridLayout_4->setSpacing(0);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_2 = new QSpacerItem(30, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_2, 0, 0, 1, 1);

        widget = new QWidget(widget_4);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lb1 = new QLabel(widget);
        lb1->setObjectName(QString::fromUtf8("lb1"));
        QFont font1;
        font1.setPointSize(16);
        lb1->setFont(font1);
        lb1->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout->addWidget(lb1, 0, 0, 1, 1);

        le_password = new QLineEdit(widget);
        le_password->setObjectName(QString::fromUtf8("le_password"));
        le_password->setMinimumSize(QSize(160, 30));
        le_password->setInputMethodHints(Qt::InputMethodHint::ImhNone);

        gridLayout->addWidget(le_password, 1, 1, 1, 1);

        le_user = new QLineEdit(widget);
        le_user->setObjectName(QString::fromUtf8("le_user"));
        le_user->setMinimumSize(QSize(160, 30));

        gridLayout->addWidget(le_user, 0, 1, 1, 1);

        lb2 = new QLabel(widget);
        lb2->setObjectName(QString::fromUtf8("lb2"));
        lb2->setFont(font1);
        lb2->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout->addWidget(lb2, 1, 0, 1, 1);


        gridLayout_4->addWidget(widget, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(30, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 0, 2, 1, 1);

        gridLayout_4->setColumnStretch(0, 10);
        gridLayout_4->setColumnStretch(1, 100);
        gridLayout_4->setColumnStretch(2, 10);

        gridLayout_3->addWidget(widget_4, 1, 0, 1, 1);

        widget_2 = new QWidget(Paeg_long);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        but_login = new QPushButton(widget_2);
        but_login->setObjectName(QString::fromUtf8("but_login"));
        but_login->setMinimumSize(QSize(200, 40));
        but_login->setMaximumSize(QSize(200, 16777215));
        but_login->setSizeIncrement(QSize(0, 0));

        gridLayout_2->addWidget(but_login, 0, 0, 1, 1);

        but_exit = new QPushButton(widget_2);
        but_exit->setObjectName(QString::fromUtf8("but_exit"));
        but_exit->setMinimumSize(QSize(200, 40));
        but_exit->setMaximumSize(QSize(200, 16777215));
        but_exit->setSizeIncrement(QSize(0, 0));

        gridLayout_2->addWidget(but_exit, 0, 1, 1, 1);


        gridLayout_3->addWidget(widget_2, 2, 0, 1, 1);


        retranslateUi(Paeg_long);

        QMetaObject::connectSlotsByName(Paeg_long);
    } // setupUi

    void retranslateUi(QWidget *Paeg_long)
    {
        Paeg_long->setWindowTitle(QApplication::translate("Paeg_long", "\347\231\273\345\275\225\347\252\227\345\217\243", nullptr));
#ifndef QT_NO_TOOLTIP
        Paeg_long->setToolTip(QApplication::translate("Paeg_long", "\350\277\231\346\230\257\347\231\273\345\275\225\347\252\227\345\217\243", nullptr));
#endif // QT_NO_TOOLTIP
        label_3->setText(QApplication::translate("Paeg_long", "\344\275\240\346\230\257\350\260\201\357\274\201", nullptr));
        lb1->setText(QApplication::translate("Paeg_long", "\347\224\250\346\210\267\345\220\215:", nullptr));
        lb2->setText(QApplication::translate("Paeg_long", "\345\257\206\347\240\201:", nullptr));
        but_login->setText(QApplication::translate("Paeg_long", "\347\231\273\345\275\225", nullptr));
        but_exit->setText(QApplication::translate("Paeg_long", "\351\200\200\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Paeg_long: public Ui_Paeg_long {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAEG_LONG_H
