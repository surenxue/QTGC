#ifndef STUSQL_H
#define STUSQL_H

#include <QObject>
#include <QSqlDatabase>
struct StuInfo
{ 
    int id;
    uint32_t xuhao;
    QString name;
    QString password;
    QString phone;
};
class stuSql : public QObject
{
    Q_OBJECT
public:

    static stuSql *ptrstuSql;//类内声明一个静态指针 需要在类外 声明一个指针访问静态变量来赋空值stuSql *stuSql::ptrstuSql =nullptr;(承接唯一实例)
    static stuSql *getinstance(){
        if(nullptr == ptrstuSql)//可能出现 ptrstuSql= nullptr  且忘记释放  会导致野指针     指针名 ptr p 成员变量 m_
        {
            ptrstuSql  =new stuSql;
        }
        return ptrstuSql;
    }


    explicit stuSql(QObject *parent = nullptr);//创建数据库管理类的实例


    void  init();

    //做一个同步接口 主线程查 主线程返回    （数据多会卡）
    //查询所有学生数量
    quint32 getStuCnt();

    //查询第几页学生数据，第0页开始
    QList<StuInfo> getPageStu(quint32 page,quint32 uiCnt);//(页数，数量)
    //增加学生
    bool addStu(StuInfo);
    bool addStu(QList<StuInfo> l);//优化

    //删除学生
    bool delStu(int id);
    //清空学生表
    bool cleaStuTable();
    //修改学生信息
    bool UpdataStuInfo(StuInfo info);//根据  info属性的id进行确定（想要修改就要为id添加具体值）
    bool updateStuByStudentId (StuInfo info);//name查询 修改
    //查询所有用户是否存在
    bool isExit(QString info);
    // 根据用户名获取 对应的所有数据
    StuInfo getUserInfoByName(const QString &username);
signals:
private:
    QSqlDatabase m_db;//作为数据库的代言人 m_db.open(打开)（关闭）（等数据库指令集操作）

};
#endif // STUSQL_H
