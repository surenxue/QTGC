#include "dianhua.h"
#include <QApplication>
#include  "stusql.h"
#include <QtSql>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    dianhua w;
    //w.show();

    stuSql sql;
    return a.exec();
}
