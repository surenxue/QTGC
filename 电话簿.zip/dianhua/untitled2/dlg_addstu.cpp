#include "dlg_addstu.h"
#include "ui_dlg_addstu.h"

#include <QMessageBox>
Dlg_AddStu::Dlg_AddStu(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dlg_AddStu)
{
    ui->setupUi(this);
}

Dlg_AddStu::~Dlg_AddStu()
{
    delete ui;
}

void Dlg_AddStu::setType(bool isAdd,StuInfo info)// 对话框被调用时，外部传入完整学生信息
{
    m_isAdd = isAdd;
    m_info = info;// 列表选择的行 数据存入  m_info  ，用于后续的读写操作
    if(isAdd == false)
    {
        //将传入info到的数放在窗口上显示；；；
        ui->le_id->setText(QString::number(info.id));
        ui->le_xuhao->setText(QString::number(info.xuhao));
        ui->le_name->setText(info.name);
        ui->le_password->setText(info.password);
        ui->le_phone->setText(info.phone);
    }
    else
    {// 因为，默认为空 当添加数据时会在部分空间出现 0 0 0
        ui->le_id->clear();
        ui->le_xuhao->clear();//txt转uint
        ui->le_name->clear();
        ui->le_password->clear();
        ui->le_phone->clear();

    }
    qDebug()<<isAdd;
}

void Dlg_AddStu::on_btn_save_clicked()//信息界面 Dlg_AddStu  保存  按下
{
    StuInfo info;
    auto ptr = stuSql::getinstance();
    info.id =  ui->le_id->text().toUInt();
    info.xuhao = ui->le_xuhao->text().toUInt();
    info.name = ui->le_name->text();
    info.password = ui->le_password->text();
    info.phone = ui->le_phone->text();

    if(m_isAdd == true)
    {
        ptr->addStu(info);//添加学生   不需要ID
        // ptr->AddUser();//添加用户

    }
    else if(m_isAdd == false)
    {
        info.id = m_info.id;//来自选中的文本框id
        ptr->UpdataStuInfo(info);//修改学生信息  需要ID
    }

    QMessageBox::information(nullptr,"信息","存储成功");
    this->hide();
}

void Dlg_AddStu::on_btn_cace_clicked()
{
    this->hide();
}
