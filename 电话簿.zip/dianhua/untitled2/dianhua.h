#ifndef DIANHUA_H
#define DIANHUA_H

#include "stusql.h"
#include "dlg_addstu.h"
#include "paeg_long.h"
#include <QMainWindow>
#include <QSqlDatabase>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui {
class dianhua;
}
QT_END_NAMESPACE

class dianhua : public QMainWindow
{
    Q_OBJECT

public:
    dianhua(QWidget *parent = nullptr);
    ~dianhua();

private slots:

     void on_pushButton_5_clicked();//产生模拟数据

    //每次将数据库更新到updateTable控件
    void updateTable();


    //退出按钮
    void on_but_exit_clicked();

    void on_btn_clear_clicked();

    void on_btn_click_clicked();

    void on_btn_shuxin_clicked();

    void on_btn_search_clicked();

    void on_btn_updata_clicked();

    void on_btn_add_clicked();

signals:
    void sendLoginSuccess_sj();

private:
    Ui::dianhua *ui;

    QStringList m_lName;//Qt 容器声明，用来存储一组字符串
    stuSql *m_ptrStuSql;//就是通过m_ptrStuSql来访问stuSql文件类下的各种成员函数吗
    Paeg_long m_dlgLogin;//声明头文件  声明一个Dlg_AddStu类对象


    Dlg_AddStu  m_dlgAddStu;//声明头文件  声明一个Dlg_AddStu类对象
};
#endif // DIANHUA_H
