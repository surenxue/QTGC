#include "page_login.h"
#include "ui_page_login.h"

Page_Login::Page_Login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Page_Login)
{
    ui->setupUi(this);
}

Page_Login::~Page_Login()
{
    delete ui;
}

void Page_Login::on_btn_login_clicked()
{
    //数据库查找账户和密码

    //失败就提示

    //成功就进入主界面

    emit sendLoginSuccess();//sendLoginSuccess() 是一个信号函数。 emit 关键字用于触发这个信号。


}

void Page_Login::on_btn_exit_clicked()
{
    exit(0);//程序退出
}
