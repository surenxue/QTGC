#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "stusql.h"
#include <QMainWindow>
#include <page_login.h>
#include <QSqlDatabase>
#include <QDebug>
#include <dlg_addstu.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


    virtual void keyPressEvent(QKeyEvent *event);//重建虚函数  按键重构皮肤
private slots:
    void on_pushButton_5_clicked();

    void on_btn_add_clicked();

    void on_btn_clear_clicked();

    void on_btn_shuxin_clicked();




    void on_btn_click_clicked();

    void on_btn_updata_clicked();

    void on_btn_search_clicked();

private:
    void updateTable();//每次将数据库更新到updateTable控件

private:
    Ui::MainWindow *ui;

    Page_Login m_dlgLogin;//这是Page_Login界面的 对象建立   用Page_Login.ui 来实体化一个界面
    Page_Login m_dlgLogin1;//与m_dlgLogin相同的一个界面   界面名->show(); 让某个界面显示出来。

    stuSql *m_ptrStuSql;
    QStringList m_lName;//Qt 容器声明，用来存储一组字符串

    Dlg_AddStu  m_dlgAddStu;//声明头文件  声明一个Dlg_AddStu类对象



};
#endif // MAINWINDOW_H
