/********************************************************************************
** Form generated from reading UI file 'dlg_addstu.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DLG_ADDSTU_H
#define UI_DLG_ADDSTU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dlg_AddStu
{
public:
    QGridLayout *gridLayout_2;
    QLabel *label_5;
    QLabel *label_7;
    QLineEdit *le_seq;
    QLineEdit *le_grade;
    QLineEdit *le_phone;
    QLabel *label_2;
    QLabel *label_6;
    QLineEdit *le_name;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label;
    QLineEdit *le_class;
    QSpinBox *sb_age;
    QLineEdit *le_wechat;
    QSpacerItem *horizontalSpacer;
    QWidget *widget;
    QGridLayout *gridLayout;
    QPushButton *btn_save;
    QPushButton *btn_cace;

    void setupUi(QDialog *Dlg_AddStu)
    {
        if (Dlg_AddStu->objectName().isEmpty())
            Dlg_AddStu->setObjectName(QString::fromUtf8("Dlg_AddStu"));
        Dlg_AddStu->resize(455, 296);
        gridLayout_2 = new QGridLayout(Dlg_AddStu);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_5 = new QLabel(Dlg_AddStu);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMinimumSize(QSize(80, 0));
        label_5->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_5, 4, 0, 1, 1);

        label_7 = new QLabel(Dlg_AddStu);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMinimumSize(QSize(80, 0));
        label_7->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_7, 6, 0, 1, 1);

        le_seq = new QLineEdit(Dlg_AddStu);
        le_seq->setObjectName(QString::fromUtf8("le_seq"));

        gridLayout_2->addWidget(le_seq, 4, 1, 1, 1);

        le_grade = new QLineEdit(Dlg_AddStu);
        le_grade->setObjectName(QString::fromUtf8("le_grade"));

        gridLayout_2->addWidget(le_grade, 3, 1, 1, 1);

        le_phone = new QLineEdit(Dlg_AddStu);
        le_phone->setObjectName(QString::fromUtf8("le_phone"));

        gridLayout_2->addWidget(le_phone, 5, 1, 1, 1);

        label_2 = new QLabel(Dlg_AddStu);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(80, 0));
        label_2->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_2, 1, 0, 1, 1);

        label_6 = new QLabel(Dlg_AddStu);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMinimumSize(QSize(80, 0));
        label_6->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_6, 5, 0, 1, 1);

        le_name = new QLineEdit(Dlg_AddStu);
        le_name->setObjectName(QString::fromUtf8("le_name"));

        gridLayout_2->addWidget(le_name, 0, 1, 1, 1);

        label_3 = new QLabel(Dlg_AddStu);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(80, 0));
        label_3->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        label_4 = new QLabel(Dlg_AddStu);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(80, 0));
        label_4->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label_4, 3, 0, 1, 1);

        label = new QLabel(Dlg_AddStu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(80, 0));
        label->setAlignment(Qt::AlignmentFlag::AlignRight|Qt::AlignmentFlag::AlignTrailing|Qt::AlignmentFlag::AlignVCenter);

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        le_class = new QLineEdit(Dlg_AddStu);
        le_class->setObjectName(QString::fromUtf8("le_class"));
        le_class->setFrame(true);
        le_class->setEchoMode(QLineEdit::EchoMode::Normal);
        le_class->setCursorPosition(0);

        gridLayout_2->addWidget(le_class, 2, 1, 1, 1);

        sb_age = new QSpinBox(Dlg_AddStu);
        sb_age->setObjectName(QString::fromUtf8("sb_age"));
        sb_age->setMaximum(100);
        sb_age->setValue(17);

        gridLayout_2->addWidget(sb_age, 1, 1, 1, 1);

        le_wechat = new QLineEdit(Dlg_AddStu);
        le_wechat->setObjectName(QString::fromUtf8("le_wechat"));

        gridLayout_2->addWidget(le_wechat, 6, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(86, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 2, 1, 1);

        widget = new QWidget(Dlg_AddStu);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        btn_save = new QPushButton(widget);
        btn_save->setObjectName(QString::fromUtf8("btn_save"));

        gridLayout->addWidget(btn_save, 0, 0, 1, 1);

        btn_cace = new QPushButton(widget);
        btn_cace->setObjectName(QString::fromUtf8("btn_cace"));

        gridLayout->addWidget(btn_cace, 0, 1, 1, 1);


        gridLayout_2->addWidget(widget, 7, 0, 1, 3);

        QWidget::setTabOrder(le_name, sb_age);
        QWidget::setTabOrder(sb_age, le_class);
        QWidget::setTabOrder(le_class, le_grade);
        QWidget::setTabOrder(le_grade, le_seq);
        QWidget::setTabOrder(le_seq, le_phone);
        QWidget::setTabOrder(le_phone, le_wechat);
        QWidget::setTabOrder(le_wechat, btn_save);
        QWidget::setTabOrder(btn_save, btn_cace);

        retranslateUi(Dlg_AddStu);

        QMetaObject::connectSlotsByName(Dlg_AddStu);
    } // setupUi

    void retranslateUi(QDialog *Dlg_AddStu)
    {
        Dlg_AddStu->setWindowTitle(QApplication::translate("Dlg_AddStu", "\346\267\273\345\212\240\345\255\246\347\224\237", nullptr));
        label_5->setText(QApplication::translate("Dlg_AddStu", "\345\255\246\345\217\267", nullptr));
        label_7->setText(QApplication::translate("Dlg_AddStu", "\345\276\256\344\277\241", nullptr));
        label_2->setText(QApplication::translate("Dlg_AddStu", "\345\271\264\351\276\204", nullptr));
        label_6->setText(QApplication::translate("Dlg_AddStu", "\347\224\265\350\257\235", nullptr));
        label_3->setText(QApplication::translate("Dlg_AddStu", "\345\271\264\347\272\247", nullptr));
        label_4->setText(QApplication::translate("Dlg_AddStu", "\347\217\255\347\272\247", nullptr));
        label->setText(QApplication::translate("Dlg_AddStu", "\345\247\223\345\220\215", nullptr));
        btn_save->setText(QApplication::translate("Dlg_AddStu", "\344\277\235\345\255\230", nullptr));
        btn_cace->setText(QApplication::translate("Dlg_AddStu", "\345\217\226\346\266\210", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dlg_AddStu: public Ui_Dlg_AddStu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DLG_ADDSTU_H
