/********************************************************************************
** Form generated from reading UI file 'page_login.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGE_LOGIN_H
#define UI_PAGE_LOGIN_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Page_Login
{
public:
    QGridLayout *gridLayout_3;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QLineEdit *le_password;
    QLabel *lb2;
    QLabel *lb1;
    QLineEdit *le_user;
    QSpacerItem *horizontalSpacer;
    QWidget *widget;
    QGridLayout *gridLayout;
    QPushButton *btn_exit;
    QPushButton *btn_login;
    QLabel *lb_title;

    void setupUi(QWidget *Page_Login)
    {
        if (Page_Login->objectName().isEmpty())
            Page_Login->setObjectName(QString::fromUtf8("Page_Login"));
        Page_Login->resize(400, 240);
        Page_Login->setMinimumSize(QSize(400, 240));
        Page_Login->setMaximumSize(QSize(400, 240));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icon.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        Page_Login->setWindowIcon(icon);
        gridLayout_3 = new QGridLayout(Page_Login);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        widget_2 = new QWidget(Page_Login);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        QFont font;
        font.setFamily(QString::fromUtf8("Nirmala UI"));
        font.setPointSize(12);
        widget_2->setFont(font);
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(25, -1, -1, -1);
        le_password = new QLineEdit(widget_2);
        le_password->setObjectName(QString::fromUtf8("le_password"));
        le_password->setMaxLength(8);
        le_password->setEchoMode(QLineEdit::EchoMode::Password);

        gridLayout_2->addWidget(le_password, 1, 1, 1, 1);

        lb2 = new QLabel(widget_2);
        lb2->setObjectName(QString::fromUtf8("lb2"));

        gridLayout_2->addWidget(lb2, 1, 0, 1, 1);

        lb1 = new QLabel(widget_2);
        lb1->setObjectName(QString::fromUtf8("lb1"));

        gridLayout_2->addWidget(lb1, 0, 0, 1, 1);

        le_user = new QLineEdit(widget_2);
        le_user->setObjectName(QString::fromUtf8("le_user"));
        le_user->setMaxLength(8);

        gridLayout_2->addWidget(le_user, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(65, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 2, 1, 1);


        gridLayout_3->addWidget(widget_2, 1, 0, 1, 1);

        widget = new QWidget(Page_Login);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMaximumSize(QSize(16777215, 50));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(2, 0, 2, 0);
        btn_exit = new QPushButton(widget);
        btn_exit->setObjectName(QString::fromUtf8("btn_exit"));
        btn_exit->setMaximumSize(QSize(16777215, 35));
        QFont font1;
        font1.setFamily(QString::fromUtf8("3ds"));
        font1.setPointSize(12);
        btn_exit->setFont(font1);

        gridLayout->addWidget(btn_exit, 0, 1, 2, 1);

        btn_login = new QPushButton(widget);
        btn_login->setObjectName(QString::fromUtf8("btn_login"));
        btn_login->setMaximumSize(QSize(16777215, 35));
        btn_login->setFont(font1);

        gridLayout->addWidget(btn_login, 0, 0, 2, 1);


        gridLayout_3->addWidget(widget, 2, 0, 1, 1);

        lb_title = new QLabel(Page_Login);
        lb_title->setObjectName(QString::fromUtf8("lb_title"));
        lb_title->setMinimumSize(QSize(0, 60));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Nirmala UI"));
        font2.setPointSize(18);
        lb_title->setFont(font2);

        gridLayout_3->addWidget(lb_title, 0, 0, 1, 1);


        retranslateUi(Page_Login);

        QMetaObject::connectSlotsByName(Page_Login);
    } // setupUi

    void retranslateUi(QWidget *Page_Login)
    {
        Page_Login->setWindowTitle(QApplication::translate("Page_Login", "\347\231\273\345\275\225", nullptr));
#ifndef QT_NO_TOOLTIP
        Page_Login->setToolTip(QApplication::translate("Page_Login", "\350\277\231\346\230\257\347\231\273\345\275\225\347\252\227\345\217\243", nullptr));
#endif // QT_NO_TOOLTIP
        le_password->setPlaceholderText(QApplication::translate("Page_Login", "\350\257\267\350\276\223\345\205\245", nullptr));
        lb2->setText(QApplication::translate("Page_Login", "<html><head/><body><p align=\"right\"><span style=\" font-size:14pt;\">\345\257\206\347\240\201</span></p></body></html>", nullptr));
        lb1->setText(QApplication::translate("Page_Login", "<html><head/><body><p align=\"right\"><span style=\" font-size:14pt;\">\347\224\250\346\210\267\345\220\215</span></p></body></html>", nullptr));
        le_user->setPlaceholderText(QApplication::translate("Page_Login", "\350\257\267\350\276\223\345\205\245", nullptr));
        btn_exit->setText(QApplication::translate("Page_Login", "\351\200\200\345\207\272", nullptr));
        btn_login->setText(QApplication::translate("Page_Login", "\347\231\273\345\275\225", nullptr));
        lb_title->setText(QApplication::translate("Page_Login", "<html><head/><body><p align=\"center\">\345\255\246\347\224\237\344\277\241\346\201\257\347\260\277</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Page_Login: public Ui_Page_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGE_LOGIN_H
