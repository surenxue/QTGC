#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QKeyEvent>
#include <QFile>
#include <QCoreApplication>
#include <QRandomGenerator>
#include <QtSql>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent) // 1. 基类构造函数初始化
    , ui(new Ui::MainWindow) // 2. 界面对象实例化
    ,m_ptrStuSql(nullptr)// 这里只是指针初始化
{

    ui->setupUi(this);//this由编译器自动设置的

//*************************************************************
    //样式内置（不需要操作读取）
    QFile fread;
    fread.setFileName(":/dlg.css");  //获取当前路径下的文件夹
    fread.open(QIODevice::ReadOnly);
    QString strQss = fread.readAll();
    m_dlgLogin.setStyleSheet(strQss);

    fread.close();
    fread.setFileName(":/main.css");
    //fread.open(QIODevice::ReadOnly);
    strQss = fread.readAll();
    this->setStyleSheet(strQss);
//*************************************************************




    m_dlgLogin.show();//执行m_dlgLogin队列  形成一个模块对话框 调用界面
    // m_dlgLogin1.show();

    //收到发送成功就自动引用
    auto f=[&](){
        this->show();
    };



    //当 sendLoginSuccess(在登录按钮槽函数用enit激发) 信号被触发时，Lambda 函数 f 会被调用，从而执行 this->show()。
    //获取来自 m_dlgLogin 界面下的 登录按钮 触发信号   Lambda 函数 f 会被调用，从而执行 this->show()。
    connect(&m_dlgLogin,&Page_Login::sendLoginSuccess,this,f);//用于连接信号和槽的语法
    //需要区分来自那个界面。
    //connect(发送者, 信号, 接收者, 槽函数);
    connect(&m_dlgLogin1,&Page_Login::sendLoginSuccess,this,f);//写了后才能从m_dlgLogin1获取信号


    //左边的树
    ui->treeWidget->clear();
    ui->treeWidget->setColumnCount(1);//设置多少列
    QStringList l;
    l<<"学生管理系统";
    QTreeWidgetItem *pf= new QTreeWidgetItem(ui->treeWidget,l);

     ui->treeWidget->addTopLevelItem(pf);
     l.clear();
     l<<"学生管理";
     QTreeWidgetItem *p1= new QTreeWidgetItem(pf,l);
     l.clear();
     l<<"管理员管理";
      QTreeWidgetItem *p2= new QTreeWidgetItem(pf,l);

    pf->addChild(p1);//将 p1 添加为 pf 的子节点,自己会随着父级显示
    pf->addChild(p2);

    ui->treeWidget->expandAll();//默认全部展开
    ui->stackedWidget->setCurrentIndex(0);


    m_ptrStuSql = stuSql::getinstance();
    m_ptrStuSql->init();//默认不打开数据库，需要初始化打开

    m_lName<<"终嘉音";
    m_lName<<"礼洁玉";
    m_lName<<"诸沛凝";
    m_lName<<"曾锦曦";
    m_lName<<"毛梓欣";
    m_lName<<"崇欣";
    m_lName<<"司徒访";
    m_lName<<"军平绿";
    m_lName<<"颛孙语";
    m_lName<<"关丰茂";
    m_lName<<"景幻梅";
    m_lName<<"桥夏月";
    m_lName<<"后晴美";
    m_lName<<"硕尔柳";
    m_lName<<"冠漠";
    m_lName<<"书寄蓉";
    m_lName<<"薛春绿";
    m_lName<<"箕温纶";
    m_lName<<"敏元菱";
    m_lName<<"宜雪枫";
    m_lName<<"贵同甫";
    m_lName<<"牢惜雪";
    m_lName<<"己雪帆";
    m_lName<<"达樱花";
    m_lName<<"祁新觉";
    m_lName<<"玉莹华";
    m_lName<<"念梦凡";
    m_lName<<"聂家美";
    m_lName<<"向精 " ;
    m_lName<<"五曼岚";
    m_lName<<"师天空";
    m_lName<<"戢芮雅";
    m_lName<<"柔才捷";
    m_lName<<"子车宏";
    m_lName<<"风彩萱";
    m_lName<<"锁和平";
    m_lName<<"丑向松";
    m_lName<<"汉骏祥";
    m_lName<<"简博简";
    m_lName<<"臧云韶";
    m_lName<<"泷凡白";
    m_lName<<"竹易巧";
    m_lName<<"罕寄蓝";
    m_lName<<"钦运华";
    m_lName<<"令琴音";
    m_lName<<"拱恨风";
    m_lName<<"字怀柔";
    m_lName<<"系慕蕊";
    m_lName<<"窦半兰";
    m_lName<<"廉访儿";
    m_lName<<"岑梦月";
    m_lName<<"烟平卉";
    m_lName<<"帖恬默";
    m_lName<<"夷兴思";
    m_lName<<"闾丘萝";
    m_lName<<"褚迎夏";
    m_lName<<"邸丽珠";
    m_lName<<"象郁 " ;
    m_lName<<"端木雪";
    m_lName<<"夏高畅";
    m_lName<<"卓芳 " ;
    m_lName<<"隆亦梅";
    m_lName<<"明忆南";
    m_lName<<"涂代灵";
    m_lName<<"谌芳泽";
    m_lName<<"帅玮艺";
    m_lName<<"沙含蕊";
    m_lName<<"段添 ";
    m_lName<<"旗冷雪";
    m_lName<<"尉凯凯";
    m_lName<<"续痴瑶";
    m_lName<<"康景行";
    m_lName<<"门冰双";
    m_lName<<"红诗柳";
    m_lName<<"无春燕";
    m_lName<<"杨怀莲";
    m_lName<<"司马怀";
    m_lName<<"悉斯";
    m_lName<<"丹采萱";
    m_lName<<"长孙英";
    m_lName<<"以荌荌";
    m_lName<<"保涵蓄";
    m_lName<<"謇语柳";
    m_lName<<"蓟慧";
    m_lName<<"鲜哲";
    m_lName<<"摩醉巧";
    m_lName<<"费莫英";
    m_lName<<"愈荡" ;
    m_lName<<"劳方方";
    m_lName<<"须浦泽";
    m_lName<<"亥千亦";
    m_lName<<"成采柳";
    m_lName<<"陈然" ;
    m_lName<<"车晓筠";
    m_lName<<"昔晓燕";
    m_lName<<"童智晖";
    m_lName<<"徭书竹";
    m_lName<<"粟韵宁";
    m_lName<<"滑浩涆";
    m_lName<<"黎元容";
    m_lName<<"壬经纬";
    m_lName<<"晋盼晴";
    m_lName<<"巩冬梅";
    m_lName<<"士旋" ;
    m_lName<<"杞俊良";
    m_lName<<"佟雅柔";
    m_lName<<"真睿姿";
    m_lName<<"孟悦乐";
    m_lName<<"弓学林";
    m_lName<<"冷英卓";
    m_lName<<"辛白夏";
    m_lName<<"首以彤";
    m_lName<<"飞香桃";
    m_lName<<"俎丹红";
    m_lName<<"毋巧兰";
    m_lName<<"荆傲霜";
    m_lName<<"杜振荣";
    m_lName<<"郜望慕";
    m_lName<<"哀昆锐";
    m_lName<<"说良" ;
    m_lName<<"齐玄雅";
    m_lName<<"旅蕴秀";
    m_lName<<"偶空" ;
    m_lName<<"归尔晴";
    m_lName<<"厍嘉悦";
    m_lName<<"覃问筠";
    m_lName<<"柏凌兰";
    m_lName<<"乌曼丽";
    m_lName<<"束青枫";
    m_lName<<"葛远" ;
    m_lName<<"海红螺";
    m_lName<<"端嘉赐";
    m_lName<<"修乐悦";
    m_lName<<"登蓓" ;
    m_lName<<"印白卉";
    m_lName<<"笪情文";
    m_lName<<"上官妙";
    m_lName<<"邶抒" ;
    m_lName<<"示子辰";
    m_lName<<"隗娜兰";
    m_lName<<"迟灵" ;
    m_lName<<"瞿悦来";
    m_lName<<"巢雅致";
    m_lName<<"建从筠";
    m_lName<<"谯澜" ;
    m_lName<<"那拉蓓";
    m_lName<<"庆沛春";
    m_lName<<"浑紫雪";
    m_lName<<"翁山梅";
    m_lName<<"集佩珍";
    m_lName<<"甫小雨";
    m_lName<<"文诗蕾";
    m_lName<<"巧白易";
    m_lName<<"邗欣美";
    m_lName<<"商玉韵";
    m_lName<<"咎语彤";
    m_lName<<"仍德华";
    m_lName<<"淡雁芙";
    m_lName<<"所偲偲";
    m_lName<<"吉泽 " ;
    m_lName<<"张简云";
    m_lName<<"贡思云";
    m_lName<<"山爰美";
    m_lName<<"公良力";
    m_lName<<"出语丝";
    m_lName<<"袁丝娜";
    m_lName<<"化高澹";
    m_lName<<"梅淼淼";
    m_lName<<"蒋凯" ;
    m_lName<<"巴向山";
    m_lName<<"牵雪峰";
    m_lName<<"始元蝶";
    m_lName<<"益曼冬";
    m_lName<<"台高寒";
    m_lName<<"苌曼文";
    m_lName<<"其悠婉";
    m_lName<<"宓秋白";
    m_lName<<"皇玉宸";
    m_lName<<"朴红豆";
    m_lName<<"百里秋";
    m_lName<<"危乐荷";
    m_lName<<"聊元武";
    m_lName<<"谷长" ;
    m_lName<<"仙忆曼";
    m_lName<<"漫书易";
    m_lName<<"桑英秀";
    m_lName<<"苍智敏";
    m_lName<<"宣景辉";
    m_lName<<"市晴霞";
    m_lName<<"沈语海";
    m_lName<<"定和昶";
    m_lName<<"纵怜容";
    m_lName<<"鄞代柔";
    m_lName<<"宋瑶岑";
    m_lName<<"天迎波";
    m_lName<<"强夏" ;
    m_lName<<"伏涵衍";
    m_lName<<"麴琼英";
    m_lName<<"谭骏年";
    m_lName<<"伟恩霈";
    m_lName<<"国献仪";
    m_lName<<"綦炳" ;
    m_lName<<"慕雁菱";
    m_lName<<"兆鸿博";
    m_lName<<"树淼" ;
    m_lName<<"载稷骞";
    m_lName<<"悟慧英";
    m_lName<<"扬洛" ;
    m_lName<<"游雨文";
    m_lName<<"洛凌翠";
    m_lName<<"夙寄波";
    m_lName<<"邴辰龙";
    m_lName<<"德忆秋";
    m_lName<<"抄杉" ;
    m_lName<<"析雪晴";
    m_lName<<"裘逸" ;
    m_lName<<"御寒天";
    m_lName<<"应盼" ;
    m_lName<<"祢雅丹";
    m_lName<<"铁初蝶";
    m_lName<<"东门丁";
    m_lName<<"京嘉瑞";
    m_lName<<"楚惠君";
    m_lName<<"辉涵桃";
    m_lName<<"路清昶";
    m_lName<<"温天韵";
    m_lName<<"凤平" ;
    m_lName<<"裴孤阳";
    m_lName<<"委新颖";
    m_lName<<"有国" ;
    m_lName<<"闳明洁";
    m_lName<<"籍流逸";
    m_lName<<"朋晟睿";
    m_lName<<"冼翰" ;
    m_lName<<"廖贞婉";
    m_lName<<"宾永宁";
    m_lName<<"督夏柳";
    m_lName<<"扈学真";
    m_lName<<"糜嘉誉";
    m_lName<<"亓翠丝";
    m_lName<<"张代珊";
    m_lName<<"申雯丽";
    m_lName<<"封若枫";
    m_lName<<"由思云";
    m_lName<<"从哲瀚";
    m_lName<<"候婉静";
    m_lName<<"张廖吉";
    m_lName<<"利文" ;
    m_lName<<"公叔蓝";
    m_lName<<"普芳润";
    m_lName<<"堂锐利";
    m_lName<<"鲜于令";
    m_lName<<"班盼香";
    m_lName<<"信凝心";
    m_lName<<"闫采春";
    m_lName<<"鲁飞兰";
    m_lName<<"速灵秀";
    m_lName<<"检丹雪";
    m_lName<<"穰芮美";
    m_lName<<"席彤霞";
    m_lName<<"闾恨荷";
    m_lName<<"局琲瓃";
    m_lName<<"琦魁" ;
    m_lName<<"之尔槐";
    m_lName<<"戚痴灵";
    m_lName<<"伍子轩";
    m_lName<<"犁俊风";
    m_lName<<"汤琅" ;
    m_lName<<"苏秋莲";
    m_lName<<"古英睿";
    m_lName<<"牟瑾 " ;
    m_lName<<"理冰菱";
    m_lName<<"函向 " ;
    m_lName<<"欧阳俊";
    m_lName<<"萨白萱";
    m_lName<<"轩辕津";
    m_lName<<"么衣" ;
    m_lName<<"称静姝";
    m_lName<<"帛思萱";
    m_lName<<"徐靖柏";
    m_lName<<"皋阳舒";
    m_lName<<"祈蝶" ;
    m_lName<<"校光亮";
    m_lName<<"泥暄和";
    m_lName<<"戴逸云";
    m_lName<<"刚清莹";
    m_lName<<"虎傲之";
    m_lName<<"似乐康";
    m_lName<<"星珺琦";
    m_lName<<"鞠冷" ;
    m_lName<<"赧雪绿";
    m_lName<<"脱剑" ;
    m_lName<<"扶凝梦";
    m_lName<<"宿恨蝶";
    m_lName<<"绳玉轩";
    m_lName<<"高寄文";
    m_lName<<"庞夜绿";
    m_lName<<"貊艳娇";
    m_lName<<"尧小楠";
    m_lName<<"鹿妙晴";
    m_lName<<"柯俊誉";
    m_lName<<"睦范" ;
    m_lName<<"召曼青";
    m_lName<<"栗建义";
    m_lName<<"侯悦和";
    m_lName<<"微生清";
    m_lName<<"荀钊" ;
    m_lName<<"傅雅静";
    m_lName<<"户秀丽";
    m_lName<<"狄初夏";
    m_lName<<"常濮存";
    m_lName<<"刁凝丝";
    m_lName<<"锐景铄";
    m_lName<<"蔺寄柔";
    m_lName<<"能蕴涵";
    m_lName<<"仝含之";
    m_lName<<"叔琳溪";
    m_lName<<"顿玉珂";
    m_lName<<"柴晨朗";
    m_lName<<"梁诗蕾";
    m_lName<<"库白凡";
    m_lName<<"闻琬凝";
    m_lName<<"阙静婉";
    m_lName<<"魏骞魁";
    m_lName<<"俟凝海";
    m_lName<<"姚奕奕";
    m_lName<<"告听枫";
    m_lName<<"戎天亦";
    m_lName<<"勇叡" ;
    m_lName<<"怀颐" ;
    m_lName<<"程醉卉";
    m_lName<<"夏侯醉";
    m_lName<<"龚尔真";
    m_lName<<"留斯伯";
    m_lName<<"骆婉丽";
    m_lName<<"酆绿夏";
    m_lName<<"但优瑗";
    m_lName<<"田北辰";
    m_lName<<"索春雪";
    m_lName<<"用从阳";
    m_lName<<"羊沛蓝";
    m_lName<<"任秋白";
    m_lName<<"哈芬菲";
    m_lName<<"区安莲";
    m_lName<<"谢震轩";
    m_lName<<"赖庸" ;
    m_lName<<"梁丘乐";
    m_lName<<"双潍" ;
    m_lName<<"逢华彩";
    m_lName<<"纳喇安";
    m_lName<<"昂小蕊";
    m_lName<<"彭仙仪";
    m_lName<<"兰郎" ;
    m_lName<<"枚冷荷";
    m_lName<<"吴水蓉";
    m_lName<<"塞勇" ;
    m_lName<<"白绮晴";
    m_lName<<"段干芳";
    m_lName<<"镜淡 " ;
    m_lName<<"邬云亭";
    m_lName<<"清隽 " ;
    m_lName<<"李斌斌";
    m_lName<<"犹彭" ;
    m_lName<<"甲谷翠";
    m_lName<<"孙博文";
    m_lName<<"邝晴虹";
    m_lName<<"晏清婉";
    m_lName<<"余知慧";
    m_lName<<"酒乐意";
    m_lName<<"第泰清";

    updateTable();


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event)//把一个样式放在文件中 按F6调用修改
{
    if(event->key() == Qt::Key_F6)//识别键盘按下f6
    {

    }
}






void MainWindow::on_pushButton_5_clicked()
{

    //制作1000条学生数据

    QRandomGenerator g,c;
    g.seed(0);//时钟置位
    c.seed(0);

    QList<StuInfo> l;//优化1

    for(int i=0;i<m_lName.size();i++){
        auto  grade = g.bounded(7,10);//1~3随机 左包括右不包括 年级
        auto  uiclass = c.bounded(1,8);//1~3随机 左包括右不包括 班级
        StuInfo info;
        if(~i){
            info.age =11;
        }
        if(i%3)
        {
            info.age =16;
        }
        if(i%7)
        {
            info.age =17;
        }
        if(i%2)
        {
            info.age =18;
        }
        info.name=m_lName[i];
        info.grade = grade;
        info.uiclass = uiclass;
        info.studentid = i;  //学号

        info.phone="1423811";
        info.wechat="123218";
        l.append(info);//info放在这个容器（数组）中  //优化2
        // m_ptrStuSql->addStu(info);//原始
    }
    m_ptrStuSql->addStu(l);//优化3

    updateTable();//刷新
}



void MainWindow::on_btn_clear_clicked()//清除成员
{
    m_ptrStuSql->cleaStuTable(); //m_ptrStuSql调用成员函数 清除学生列表
    updateTable();//刷新
}

void MainWindow::updateTable()//刷新 下拉栏
{
    ui->tableWidget->clear();//会删除表头
    ui->tableWidget->setColumnCount(9);//设为8列
    QStringList l;//表头
    l<<"序号"<<"id"<<"姓名"<<"年龄"<<"年级"<<"班级"<<"学号"<<"电话"<<"微信";//qDebug() << l[1]; // 输出：姓名
    ui->tableWidget->setHorizontalHeaderLabels(l);//设置水平

    //一行任意位置选中行  行为
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    //每个选项不可编辑
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);


    auto cnt = m_ptrStuSql->getStuCnt();//把所有数据拿出  // 根据函数返回值推断类型 自适应类型（自动变化）
    ui->lb_cnt->setText(QString("学生总数:%1").arg(cnt));
    QList<StuInfo> lStudents = m_ptrStuSql->getPageStu(0,cnt);//0页，cnt个

    //ui->tableWidget->clear();
    ui->tableWidget->setRowCount(cnt);//一共cnt个
    for(int i=0;i<lStudents.size();i++){
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(i)));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::number(lStudents[i].id)));
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(lStudents[i].name));
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(lStudents[i].age)));
        ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(lStudents[i].grade)));
        ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::number(lStudents[i].uiclass)));
        ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::number(lStudents[i].studentid, 10)));
        ui->tableWidget->setItem(i,7,new QTableWidgetItem(lStudents[i].phone));
        ui->tableWidget->setItem(i,8,new QTableWidgetItem(lStudents[i].wechat));

    }

}


void MainWindow::on_btn_shuxin_clicked()
{
    updateTable();//刷新
}
void MainWindow::on_btn_add_clicked()//添加学生按钮
{
    //m_dlgAddStu.show();//声明完后按钮启动新界面  显示屏幕

    //无需输入数据   就直接启动文件（窗口）
    m_dlgAddStu.setType(true);
    m_dlgAddStu.exec();// 阻塞 强制完成当前窗口（必须有个返回）  模态对话框    m_dlgAddStu 是  Dlg_AddStu 窗口下的一个对象    开启窗口
    //m_dlgAddStu.show();打开，与其他界面共存
    updateTable();//刷新
}

void MainWindow::on_btn_updata_clicked()// 修改学生按钮
{
    StuInfo info;
    int i = ui->tableWidget->currentRow();//获取当前是第几行
    if(i>=0){

        //拿出主界面选中信息

        info.id = ui->tableWidget->item(i,1)->text().toUInt();


        info.name   = ui->tableWidget->item(i,2)->text();
        info.age  = ui->tableWidget->item(i,3)->text().toUInt();
        info.grade  = ui->tableWidget->item(i,4)->text().toUInt();
        info.uiclass  = ui->tableWidget->item(i,5)->text().toUInt();
        info.studentid  = ui->tableWidget->item(i,6)->text().toUInt();
        qDebug()<< info.studentid;
        info.phone  = ui->tableWidget->item(i,7)->text();
        info.wechat  = ui->tableWidget->item(i,8)->text();

        m_dlgAddStu.setType(false,info);//true    //拿出主界面  整个对象数据一起发出  包括  id
        m_dlgAddStu.exec();// 阻塞 强制完成当前窗口（必须有个返回）  模态对话框
    }
    updateTable();//刷新
}
void MainWindow::on_btn_click_clicked()//选中，删除当前选中行
{
    int i = ui->tableWidget->currentRow();//获取当前是第几行
    if(i>=0){
        int id = ui->tableWidget->item(i,1)->text().toUInt();
        m_ptrStuSql->delStu(id);
        updateTable();
        QMessageBox::information(nullptr,"信息","删除成功");
    }

}

void MainWindow::on_btn_search_clicked()//搜索
{

    QString strFile = ui->le_search->text();
    if(strFile.isEmpty()){
        QMessageBox::information(nullptr,"警告","名字筛选为空");
        updateTable();
        return;

    }
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(9);//设为8列
    QStringList l;//表头
    l<<"序号"<<"id"<<"姓名"<<"年龄"<<"年级"<<"班级"<<"学号"<<"电话"<<"微信";//qDebug() << l[1]; // 输出：姓名
    ui->tableWidget->setHorizontalHeaderLabels(l);//设置水平

    auto cnt = m_ptrStuSql->getStuCnt();//把所有数据拿出  // 根据函数返回值推断类型 自适应类型（自动变化）
    ui->lb_cnt->setText(QString("学生总数:%1").arg(cnt));
    QList<StuInfo> lStudents = m_ptrStuSql->getPageStu(0,cnt);//0页，cnt个
    //ui->tableWidget->clear();


    //ui->tableWidget->setRowCount(cnt);//一共cnt个
    ui->tableWidget->setRowCount(0); // 清空现有行（修复空白行问题）
    int index = 0;

    for(int i=0;i<lStudents.size();i++){
        //Students[i].name.contains(strFile) Students[i].name是否包含  strFile
        QString studentIdStr = QString::number(lStudents[i].studentid);
        if(lStudents[i].name.contains(strFile) ||  // 改为逻辑或
            studentIdStr.contains(strFile))
        {
            ui->tableWidget->insertRow(index); // 插入新行
            ui->tableWidget->setItem(index,0,new QTableWidgetItem(QString::number(index+1)));
            ui->tableWidget->setItem(index,0,new QTableWidgetItem(QString::number(index+1)));//将序列从一开始
            ui->tableWidget->setItem(index,1,new QTableWidgetItem(QString::number(lStudents[i].id)));
            ui->tableWidget->setItem(index,2,new QTableWidgetItem(lStudents[i].name));
            ui->tableWidget->setItem(index,3,new QTableWidgetItem(QString::number(lStudents[i].age)));
            ui->tableWidget->setItem(index,4,new QTableWidgetItem(QString::number(lStudents[i].grade)));
            ui->tableWidget->setItem(index,5,new QTableWidgetItem(QString::number(lStudents[i].uiclass)));
            ui->tableWidget->setItem(index,6,new QTableWidgetItem(QString::number(lStudents[i].studentid, 10)));
            ui->tableWidget->setItem(index,7,new QTableWidgetItem(lStudents[i].phone));
            ui->tableWidget->setItem(index,8,new QTableWidgetItem(lStudents[i].wechat));
            index++;
        }
    }
    ui->tableWidget->setRowCount(index);//全放在内存中
}

