#include "stusql.h"
#include <QMessageBox>
#include <QCoreApplication>
#include <QtSql>
#include <QtDebug>

stuSql *stuSql::ptrstuSql =nullptr;
stuSql::stuSql(QObject *parent)
     : QObject{parent}
{
    init();


    StuInfo s;
    s.age =4;
    s.studentid=10927136;
    s.name= "aaaa";
    //getStuCnt(); 查询所有学生数量
    getPageStu(0,2);//从第0页查，每页2个（函数返回值处加断点课Debug）
    //addStu(s);  // 添加学生数据  完成
    //delStu(125);//根据id进行删除对象  完成
    //cleaStuTable();//清空学生列表  完成
    /*s.id=127;
    UpdataStuInfo(s);//为现有对象添加id属性进行查找定位修改对象 id不可修改  完成*/
    //updateStuByStudentId (s);//为现有对象添加studentid属性进行查找定位修改对象 id不可修改（疑似数据库设置为主键）  完成


    /* QSqlQuery q("", db);//设置数据库路径
    //该语句仅能写，在已有的数据上 不能重复写  不能修改   需要语句
     q.exec("INSERT INTO student VALUES (2, '张三', 12, 3, 2, 1, 15940224444, 'asdzhang');");*/


    UserInfo info;
    info.username="xiao0yu";
    info.password="123456";
    info.auth="admin";
    //auto l = getAllUser();//查询所有用户 完成
    //qDebug()<<isExit("xiao0yu"); //查询用户 完成
    //AddUser(info);//添加用户  完成
    /*info.password="666000";
    updateUser(info);//修改用户为现有对象添加username属性进行查找定位修改对象  完成*/

    //delUser("xiao0yu");//删除用户 （根据username锁定） 完成




}

void stuSql::init()//数据库初始化
{
    if (QSqlDatabase::drivers().isEmpty())
        qDebug()<<"No database drivers found";

    //      QMessageBox::information(nullptr, tr("No database drivers found"),
    //                               tr("This demo requires at least one Qt database driver. "
    //                                  "Please check the documentation how to build the "
    //                                  "Qt SQL plugins."));
    m_db = QSqlDatabase::addDatabase("QSQLITE");//数据库驱动名字
#if 1 //打包时为1

    auto str = QCoreApplication::applicationDirPath()+"/data.db";//程序发给别人需要装上一个数据库（获取应用程序当前Debug的路径）
    qDebug()<< str;
#endif
     // auto str = "c:/Users/Administrator/Desktop/QTgc/shujuku/stumgr/data.db";
     qDebug() << "数据库路径:" << QDir::toNativeSeparators(str);//（检查获取应用程序当前Debug的路径）
    //  C:/Users/Administrator/Desktop/QTgc/shujuku/stumgr/build/Desktop_Qt_6_8_2_MinGW_64_bit-Debug/debug/data.db

    m_db.setDatabaseName(str);
    if (!m_db.open()) {
        qDebug() << "Database open error:" << m_db.lastError().text(); // 添加详细错误信息
        return;
    }
//输出
    //  QMessageBox::warning(nullptr, tr("Unable to open database"), tr("An error occurred while "));
    // "opening the connection: ") + db.lastError().text());
}

quint32 stuSql::getStuCnt()
{
    QSqlQuery sql(m_db);
    sql.exec("select count(id) from student;");
    quint32 uiCnt=0;
    while(sql.next()){
    uiCnt =  sql.value(0).toUInt();
    }
    qDebug()<<uiCnt;
    return uiCnt;
}

QList<StuInfo> stuSql::getPageStu(quint32 page, quint32 uiCnt)//(页数，数量)
{
    QList<StuInfo> l;
    QSqlQuery sql(m_db);
    //一页多少个 从哪开始
    QString  strsql = QString("select * from student order by id limit %1 offset %2")//你要查多少个从哪开始查
                     .arg(uiCnt).arg(page*uiCnt);
    sql.exec(strsql);//你要查多少个
    StuInfo info;
    while(sql.next()){
        info.id =  sql.value(0).toUInt();
        info.name = sql.value(1).toString();
        info.age =  sql.value(2).toUInt();
        info.grade =  sql.value(3).toUInt();
        info.uiclass =  sql.value(4).toUInt();
        info.studentid =  sql.value(5).toUInt();
        info.phone =  sql.value(6).toString();
        info.wechat =  sql.value(7).toString();
        l.push_back(info);
    }

    return l;
}

bool stuSql::addStu(StuInfo info)
{
    QSqlQuery sql(m_db);
    QString strSql = QString("insert into student values(null,'%1',%2,%3,%4,%5,'%6','%7');").
                     arg(info.name).
                     arg(info.age).
                     arg(info.grade).
                     arg(info.uiclass).
                     arg(info.studentid).
                     arg(info.phone).
                     arg(info.wechat);
    // qDebug()<<sql.exec(strSql);
    // return 0;
    return sql.exec(strSql);
}

bool stuSql::addStu(QList<StuInfo> l)//优化
{
    QSqlQuery sql(m_db);
    m_db.transaction();
    for(auto info:l)
    {
        QString strSql = QString("insert into student values(null,'%1',%2,%3,%4,%5,'%6','%7');").
                         arg(info.name).
                         arg(info.age).
                         arg(info.grade).
                         arg(info.uiclass).
                         arg(info.studentid).
                         arg(info.phone).
                         arg(info.wechat);
        sql.exec(strSql);

    }

    return true;
}



bool stuSql::delStu(int id)
{
    QSqlQuery sql(m_db);

    return sql.exec(QString("delete from student where id = %1;").arg(id));;
}

bool stuSql::updateStuByStudentId (StuInfo info)
{
    QSqlQuery sql(m_db);

    // 使用预编译语句和参数绑定，避免 SQL 注入
    QString strSql = QString("UPDATE student SET name=:name, age=:age, grade=:grade, class=:class, "
                             "phone=:phone, wechat=:wechat WHERE studentid=:studentid");

    sql.prepare(strSql);
    sql.bindValue(":name", info.name);
    sql.bindValue(":age", info.age);
    sql.bindValue(":grade", info.grade);
    sql.bindValue(":class", info.uiclass);
    sql.bindValue(":phone", info.phone);
    sql.bindValue(":wechat", info.wechat);
    sql.bindValue(":studentid", info.studentid);

    // 执行 SQL 语句
    bool ret = sql.exec();

    // 错误处理
    if (!ret) {
        QSqlError e = sql.lastError();
        qDebug() << "SQL 错误:" << e.text(); // 输出错误信息
        return false; // 返回 false 表示操作失败
    }

    return true; // 返回 true 表示操作成功
}

bool stuSql::cleaStuTable()
{
    QSqlQuery sql(m_db);

    sql.exec("delete from student ");

    return sql.exec("delete from sqlite_sequence where name='student'");

}

bool stuSql::UpdataStuInfo(StuInfo info)
{
    QSqlQuery sql(m_db);
    //采用数据库中的字段  不是自己的变量名
    QString strSql = QString("update student set name='%1',age =%2,grade=%3 , class=%4,studentid=%5,"
                             "phone='%6',wechat='%7' where id=%8").
                     arg(info.name).
                     arg(info.age).
                     arg(info.grade).
                     arg(info.uiclass).
                     arg(info.studentid).
                     arg(info.phone).
                     arg(info.wechat).arg(info.id);
    bool ret = sql.exec(strSql);
    QSqlError e = sql.lastError();
    if(e.isValid()){
    qDebug()<<e.text();
    }
    return ret;
}

QList<UserInfo> stuSql::getAllUser()
{
    QList<UserInfo> l;
    QSqlQuery sql(m_db);
    sql.exec("select * from username");

    UserInfo info;
    while(sql.next()){
        info.username =  sql.value(0).toString();
        info.password = sql.value(1).toString();
        info.auth =  sql.value(2).toString();
        l.push_back(info);
    }
    return l;
}

bool stuSql::isExit(QString strUser)
{
    QSqlQuery sql(m_db);
    sql.exec(QString("select *from username where username='%1'").arg(strUser));
    return sql.next();
}

bool stuSql::updateUser(UserInfo info)
{
    QSqlQuery sql(m_db);
    QString strSql = QString("update username set password='%1',auth ='%2' where username='%3'")
                    .arg(info.password)
                    .arg(info.auth)
                    .arg(info.username);
    bool ret = sql.exec(strSql);
    QSqlError e = sql.lastError();
    if(e.isValid()){
        qDebug()<<e.text()<<"  adas";
    }
    return ret;
}

bool stuSql::AddUser(UserInfo info)
{
    QSqlQuery sql(m_db);
    QString strSql = QString("insert into username values ('%1', '%2', '%3')").
                     arg(info.username).
                     arg(info.password).
                     arg(info.auth);

    return sql.exec(strSql);
}

bool stuSql::delUser(QString strUserName)
{
    QSqlQuery sql(m_db);
   return sql.exec(QString("delete from username where username='%1'").arg(strUserName));

}



