/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGridLayout *gridLayout;
    QPushButton *btn_click;
    QLabel *lb_cnt;
    QPushButton *btn_clear;
    QTableWidget *tableWidget;
    QPushButton *btn_add;
    QLineEdit *le_search;
    QCheckBox *checkBox;
    QPushButton *pushButton_5;
    QPushButton *btn_updata;
    QPushButton *btn_search;
    QPushButton *btn_shuxin;
    QWidget *page_2;
    QTreeWidget *treeWidget;
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QWidget *widget_3;
    QGridLayout *gridLayout_4;
    QLabel *lb_user;
    QPushButton *but_exit;
    QLabel *label_3;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1260, 715);
        MainWindow->setMinimumSize(QSize(800, 480));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icon.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget#centralwidget{background-color:#24495e;} ;"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setToolTipDuration(-1);
        stackedWidget->setStyleSheet(QString::fromUtf8(""));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        gridLayout = new QGridLayout(page);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        btn_click = new QPushButton(page);
        btn_click->setObjectName(QString::fromUtf8("btn_click"));
        btn_click->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_click, 0, 5, 1, 1);

        lb_cnt = new QLabel(page);
        lb_cnt->setObjectName(QString::fromUtf8("lb_cnt"));

        gridLayout->addWidget(lb_cnt, 2, 3, 1, 1);

        btn_clear = new QPushButton(page);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));

        gridLayout->addWidget(btn_clear, 2, 1, 1, 1);

        tableWidget = new QTableWidget(page);
        if (tableWidget->rowCount() < 1)
            tableWidget->setRowCount(1);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setStyleSheet(QString::fromUtf8("background-color: #75afaf;\n"
""));
        tableWidget->horizontalHeader()->setStretchLastSection(true);
        tableWidget->verticalHeader()->setVisible(false);

        gridLayout->addWidget(tableWidget, 1, 0, 1, 12);

        btn_add = new QPushButton(page);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));
        btn_add->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_add, 0, 3, 1, 1);

        le_search = new QLineEdit(page);
        le_search->setObjectName(QString::fromUtf8("le_search"));
        le_search->setMaximumSize(QSize(600, 300));
        le_search->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        gridLayout->addWidget(le_search, 0, 6, 1, 1);

        checkBox = new QCheckBox(page);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 0, 0, 1, 1);

        pushButton_5 = new QPushButton(page);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        gridLayout->addWidget(pushButton_5, 2, 0, 1, 1);

        btn_updata = new QPushButton(page);
        btn_updata->setObjectName(QString::fromUtf8("btn_updata"));
        btn_updata->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_updata, 0, 4, 1, 1);

        btn_search = new QPushButton(page);
        btn_search->setObjectName(QString::fromUtf8("btn_search"));
        btn_search->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout->addWidget(btn_search, 0, 8, 1, 1);

        btn_shuxin = new QPushButton(page);
        btn_shuxin->setObjectName(QString::fromUtf8("btn_shuxin"));

        gridLayout->addWidget(btn_shuxin, 2, 2, 1, 1);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        stackedWidget->addWidget(page_2);

        gridLayout_3->addWidget(stackedWidget, 1, 1, 1, 1);

        treeWidget = new QTreeWidget(centralwidget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setMinimumSize(QSize(0, 0));
        treeWidget->setMaximumSize(QSize(175, 600));
        treeWidget->setStyleSheet(QString::fromUtf8("background-color:#24495e;"));
        treeWidget->header()->setVisible(false);

        gridLayout_3->addWidget(treeWidget, 1, 0, 1, 1);

        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(500, 60));
        widget->setStyleSheet(QString::fromUtf8("background-color:#24495e;"));
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMargin(-2);

        gridLayout_2->addWidget(label, 0, 1, 1, 1);

        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMinimumSize(QSize(360, 50));
        gridLayout_4 = new QGridLayout(widget_3);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        lb_user = new QLabel(widget_3);
        lb_user->setObjectName(QString::fromUtf8("lb_user"));
        lb_user->setMinimumSize(QSize(0, 30));
        lb_user->setMaximumSize(QSize(16777215, 40));

        gridLayout_4->addWidget(lb_user, 0, 2, 1, 1);

        but_exit = new QPushButton(widget_3);
        but_exit->setObjectName(QString::fromUtf8("but_exit"));
        but_exit->setMinimumSize(QSize(0, 30));
        but_exit->setMaximumSize(QSize(16777215, 30));
        but_exit->setStyleSheet(QString::fromUtf8("background-color: #75afaf;"));

        gridLayout_4->addWidget(but_exit, 0, 3, 1, 1);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(60, 60));
        label_3->setMaximumSize(QSize(60, 60));
        label_3->setStyleSheet(QString::fromUtf8("border-image:url(:/icon.jpg);"));

        gridLayout_4->addWidget(label_3, 0, 0, 1, 1);

        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 60));

        gridLayout_4->addWidget(label_2, 0, 1, 1, 1);


        gridLayout_2->addWidget(widget_3, 0, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 0, 1, 1);

        gridLayout_2->setColumnStretch(0, 1);
        gridLayout_2->setColumnStretch(1, 1);
        gridLayout_2->setColumnStretch(2, 1);

        gridLayout_3->addWidget(widget, 0, 0, 1, 2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1260, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\345\255\246\347\224\237\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
#ifndef QT_NO_TOOLTIP
        MainWindow->setToolTip(QApplication::translate("MainWindow", "\350\277\231\346\230\257\345\255\246\347\224\237\347\256\241\347\220\206\347\263\273\347\273\237\357\274\210\351\274\240\346\240\207\346\202\254\345\201\234\346\217\220\347\244\272\357\274\211", nullptr));
#endif // QT_NO_TOOLTIP
        btn_click->setText(QApplication::translate("MainWindow", "\345\210\240\351\231\244", nullptr));
        btn_click->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        lb_cnt->setText(QString());
        btn_clear->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272\345\255\246\347\224\237\350\241\250", nullptr));
        tableWidget->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        btn_add->setText(QApplication::translate("MainWindow", "\345\242\236\345\212\240", nullptr));
        btn_add->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        le_search->setText(QString());
        checkBox->setText(QApplication::translate("MainWindow", "\345\205\250\351\200\211", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
        btn_updata->setText(QApplication::translate("MainWindow", "\344\277\256\346\224\271", nullptr));
        btn_updata->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        btn_search->setText(QApplication::translate("MainWindow", "\346\220\234\347\264\242", nullptr));
        btn_search->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        btn_shuxin->setText(QApplication::translate("MainWindow", "\345\210\267\346\226\260", nullptr));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt;\">\345\255\246\347\224\237\344\277\241\346\201\257\347\260\277</span></p></body></html>", nullptr));
        lb_user->setText(QApplication::translate("MainWindow", "admin", nullptr));
        but_exit->setText(QApplication::translate("MainWindow", "\351\200\200\345\207\272", nullptr));
        but_exit->setProperty("btn", QVariant(QApplication::translate("MainWindow", "main", nullptr)));
        label_3->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
