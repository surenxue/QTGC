#include "mainwindow.h"
#include "page_login.h"
#include <QApplication>
#include  "stusql.h"
#include <QtSql>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;


    stuSql sql;

    //w.show();调用界面


    return a.exec();
}
