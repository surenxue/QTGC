#ifndef DLG_ADDSTU_H
#define DLG_ADDSTU_H

#include <QDialog>
#include <QtSql>
#include "stusql.h"  //数据类
namespace Ui {
class Dlg_AddStu;
}

class Dlg_AddStu : public QDialog
{
    Q_OBJECT

public:
    explicit Dlg_AddStu(QWidget *parent = nullptr);
    ~Dlg_AddStu();

    void setType(bool isAdd,StuInfo info ={});//创建变量来实现一个窗口的复用

private slots:
    void on_btn_save_clicked();

    void on_btn_cace_clicked();

private:
    Ui::Dlg_AddStu *ui;
    bool m_isAdd;//创建变量来实现
    StuInfo m_info;
};

#endif // DLG_ADDSTU_H
